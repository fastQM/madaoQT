package main

import (
	"encoding/json"
	"fmt"
	"log"
	"madaoQT/exchange"
	"madaoQT/task/trend"
)

func main() {

	trendTask := new(trend.TrendOkex)

	config := trend.TrendConfig{
		Pair:            "eth/usdt",
		Interval:        exchange.KlinePeriod15Min,
		UnitAmount:      100,
		LimitCloseRatio: 0.06,
		LimitOpenRatio:  0.002,
		LossLimit:       0.2,
		FundRatio:       0.1,
		OpenLong:        true,
		OpenShort:       true,
	}

	jsonConfig, err := json.Marshal(config)
	if err != nil {
		log.Printf("Error:%v", err)
		return
	}

	err = trendTask.Start(string(jsonConfig))
	if err != nil {
		log.Printf("Error:%v", err)
		return
	}

	go func() {
		var cmd string
		for {
			fmt.Scanln(&cmd)

			switch cmd {
			case "c":
				trendTask.ForceClosePositions()
				cmd = ""
			}
		}
	}()
	select {}
}
