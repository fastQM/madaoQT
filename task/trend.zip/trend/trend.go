package trend

import (
	Global "madaoQT/config"
	Exchange "madaoQT/exchange"
	Mongo "madaoQT/mongo"

	"github.com/kataras/golog"
)

type TrendConfig struct {
	Pair string `json:"pair"`

	// 观察周期
	Interval int

	// 资金使用比例
	FundRatio float64 `json:"fundratio"`
	OpenLong  bool    `json:"openlong"`
	OpenShort bool    `json:"openshort"`
	// 单笔订单下单金额
	UnitAmount float64 `json:"unitamount"`
	// 强制平仓点
	LimitCloseRatio float64 `json:"limitcloseratio"`
	// 开仓允许价差
	LimitOpenRatio float64 `json:"limitopenratio"`

	// 爆仓控制，防止个别大单市价交易导致低价格成交
	LossLimit float64 `json:"losslimit"`
}

type TrendPosition struct {
	TimeStamp int64
	Amount    float64
	config    Exchange.TradeConfig
}

const TradingPeriodMS = 1000
const CheckingPeriodMS = 10 * 1000

// "mongodb://127.0.0.1:28017"
const MongoServer = "mongodb://localhost:27017"

var Logger *golog.Logger

func init() {
	logger := golog.New()
	Logger = logger
	Logger.SetLevel("debug")
	Logger.SetTimeFormat(Global.TimeFormat)
	Logger.SetPrefix("[TREN]")
}

func getExchangeKey(exchangeName string) (error, *Exchange.ExchangeInfo) {
	mongo := &Mongo.ExchangeDB{
		Server: MongoServer,
		// Sock5Proxy: "SOCKS5:127.0.0.1:1080",
	}

	err, record := Exchange.GetExchangeKey(mongo, exchangeName, nil, nil)
	if err != nil {
		return err, nil
	}

	return nil, record
}
