package trend

import (
	"encoding/json"
	"errors"
	"log"
	"sync"
	"time"

	Global "madaoQT/config"
	Exchange "madaoQT/exchange"
	Mongo "madaoQT/mongo"
	MongoTrend "madaoQT/mongo/trend"
	Task "madaoQT/task"
	Utils "madaoQT/utils"
)

const FxcmToken = "56e42ea41ef59249bba881f9b21399d6a04c5772"
const FxcmTaskExplaination = "该策略应用于外汇市场"

const FXCMTradingPeriodMS = 1000
const FXCMCheckingPeriodMS = 60 * 1000 / 2

// 1. 只做和大趋势相同的方向，即上升通道不做空，下降通道不做多

// FXCMTrend 策略适用于在短期内(1-3天)出现大幅波动(10%-30%)的市场
type FXCMTrend struct {
	config TrendConfig

	fxcm *Exchange.FXCM

	status       Task.StatusType
	database     *MongoTrend.TrendMongo
	tradeManager *TradeManager
	balance      float64

	klines []Exchange.KlineValue

	positions     map[uint]*TrendPosition
	positionIndex uint

	checkPeriodSec time.Duration

	// 强制平仓
	forceCloseFlag   bool
	forceCloseLength int
	// 部分平仓后可建仓位
	forcePartialBalance float64
	forceAddFlag        bool

	errorCounter int
}

type FXCMTradeResult struct {
	TradeID    string
	Error      Task.TaskErrorType
	DealAmount float64 // 已成交金额，如果部分成交，需要将该部分平仓
	AvgPrice   float64
}

var FXCMDefaultConfig = TrendConfig{
	Pair:            Exchange.FxcmPairEURUSD,
	Interval:        Exchange.KlinePeriod1Day,
	OpenLong:        true,
	OpenShort:       true,
	UnitAmount:      1, // 对应0.01手
	LimitCloseRatio: 0.005,
	// LimitOpenRatio:  0.002,
	// LossLimit:       0.2,
	FundRatio: 0.1,
}

func (p *FXCMTrend) GetDescription() Task.Description {

	return Task.Description{
		Name:  "福汇外汇趋势交易",
		Title: "福汇外汇趋势交易",
		Desc:  "该策略主要跟踪大幅上涨或者下跌的趋势",
	}
}

func (p *FXCMTrend) GetDefaultConfig() interface{} {
	return FXCMDefaultConfig
}
func (p *FXCMTrend) GetBalances() map[string]interface{} {

	return p.fxcm.GetBalance()

}
func (p *FXCMTrend) GetTrades() []Mongo.TradesRecord {
	return nil
}
func (p *FXCMTrend) GetPositions() []map[string]interface{} {
	var positions []MongoTrend.TradeInfo

	err1, closedPositions := p.tradeManager.GetClosedPositions()
	if err1 != nil {
		Logger.Errorf("GetPositions:Fail to get closed positions %v", err1)
		return nil
	}
	positions = append(positions, closedPositions...)

	err2, openPositions := p.tradeManager.GetOpenPositions(p.config.Pair)
	if err2 != nil {
		Logger.Errorf("GetPositions:Fail to get open positions %v", err2)
		return nil
	}

	positions = append(positions, openPositions...)

	return nil
}
func (p *FXCMTrend) GetFailedPositions() []map[string]interface{} {
	return nil
}
func (p *FXCMTrend) FixFailedPosition(updateJSON string) error {
	return nil
}
func (p *FXCMTrend) Close() {
	return
}
func (p *FXCMTrend) GetStatus() Task.StatusType {
	return p.status
}

func (p *FXCMTrend) Start(configJSON string) error {

	Logger.Infof("%s", trendTaskExplaination)

	if configJSON == "" {
		p.config = p.GetDefaultConfig().(TrendConfig)
	} else {
		var config TrendConfig
		err := json.Unmarshal([]byte(configJSON), &config)
		if err != nil {
			log.Printf("Fail to get config:%v", err)
			return errors.New(Task.TaskErrorMsg[Task.TaskInvalidConfig])
		}
		p.config = config
	}

	Logger.Info("===========配置(FXCM)=====================")
	Logger.Infof("货币:%v", p.config.Pair)
	Logger.Infof("检测周期:%v(分钟)", p.config.Interval)
	Logger.Infof("下单单位:%v(0.01手)", p.config.UnitAmount)
	Logger.Infof("是否开空:%v, 是否开多:%v", p.config.OpenLong, p.config.OpenShort)
	Logger.Infof("交易记录数据库名：%s", Task.TrendTradeCollectionFXCM)
	Logger.Infof("资金数据库名:%s", Task.TrendBalanceFXCM)
	Logger.Info("==========================================")

	p.status = Task.StatusProcessing
	p.checkPeriodSec = FXCMCheckingPeriodMS
	p.forcePartialBalance = 1.0

	p.database = &MongoTrend.TrendMongo{
		TradeCollectionName:   Task.TrendTradeCollectionFXCM,
		BalanceCollectionName: Task.TrendBalanceFXCM,
		Server:                MongoServer,
		// Sock5Proxy:            "SOCKS5:127.0.0.1:1080",
	}
	if err := p.database.Connect(); err != nil {
		Logger.Errorf("Error:%v", err)
		return err
	}

	p.tradeManager = new(TradeManager)
	p.tradeManager.Init(p.database.TradeCollection)
	p.positions = make(map[uint]*TrendPosition)
	p.loadPosition()

	p.fxcm = Exchange.GetFxcmInstance(Exchange.Config{
		Custom: map[string]interface{}{
			"token":   FxcmToken,
			"account": "96080958",
		},
	})

	go func() {
		for {
			select {
			case event := <-p.fxcm.WatchEvent():
				if event == Exchange.EventConnected {
					p.Watch()
				} else if event == Exchange.EventLostConnection {
					p.fxcm.Close()
					go Task.Reconnect(p.fxcm)
				}
			case <-time.After(p.checkPeriodSec * time.Millisecond):
				if p.status == Task.StatusError || p.status == Task.StatusNone {
					Logger.Debug("状态异常或退出")
					return
				}

				p.database.Refresh()
				p.Watch()
			}
		}
	}()

	return nil
}

func (p *FXCMTrend) loadPosition() {
	var records []MongoTrend.TradeInfo
	var err error

	if err, records = p.tradeManager.GetOpenPositions(p.config.Pair); err != nil {
		Logger.Errorf("Fail to load positions:%v", err)
		return
	}

	if records != nil && len(records) > 0 {
		for _, record := range records {
			var position TrendPosition
			var config Exchange.TradeConfig
			config.Batch = record.Batch
			config.Amount = record.FutureAmount
			config.Limit = p.config.LimitOpenRatio
			config.Pair = record.Pair
			config.Type = Exchange.TradeTypeInt(record.FutureType)
			config.Price = record.FutureOpen
			position.TimeStamp = record.OpenTime.Unix()
			position.Amount = config.Amount
			position.config = config
			p.positions[p.positionIndex] = &position
			p.positionIndex++
			Logger.Infof("Position:%v", position)
		}
	}
}

func (p *FXCMTrend) checkFunds(latestPrice float64) float64 {

	var usedAmount float64
	for _, position := range p.positions {
		usedAmount += position.Amount
	}

	if usedAmount == 0 && p.balance == 0 {

		balance := p.GetBalances()
		p.balance = balance["balance"].(float64)
		p.balance = float64(int(p.balance * p.config.FundRatio / Exchange.MapDeposit[Exchange.FxcmPairEURUSD]))
		p.config.UnitAmount = p.balance // 一次全部开完

		var balanceData MongoTrend.BalanceInfo
		balanceData.Item = make([]MongoTrend.BalanceItemInfo, 1)
		balanceData.Item[0] = MongoTrend.BalanceItemInfo{
			Coin:    p.config.Pair,
			Balance: balance["balance"].(float64),
		}
		if err := p.database.BalanceCollection.Insert(balanceData); err != nil {
			Logger.Errorf("Invalid to save data:%v", err)
		}
	} else {

		if p.forceAddFlag {
			p.balance = p.balance * 2
			p.forceAddFlag = false
		}
	}

	Logger.Infof("总手:%v 开仓手数：%v 已开仓：%v", p.balance, p.config.UnitAmount, usedAmount)
	if (usedAmount + p.config.UnitAmount) > p.balance {
		return 0
	}
	return p.config.UnitAmount

}

func (p *FXCMTrend) Watch() {

	if p.klines == nil || len(p.klines) == 0 {
		p.klines = p.fxcm.GetKline(p.config.Pair, p.config.Interval, 200)
		if p.klines == nil {
			Logger.Errorf("未获取均线信息")
			return
		}

		p.klines = append(p.klines, Exchange.KlineValue{
			OpenTime: float64(time.Now().Unix()),
		})
		return

	} else {
		// current := p.klines[len(p.klines)-1]

		// if time.Now().Unix()-int64(current.OpenTime) > int64(p.config.Interval*60*2) {
		// 	p.klines = nil
		// 	Logger.Info("更新均线")
		// 	return
		now := time.Now()
		updateTime := time.Date(now.Year(), now.Month(), now.Day(), 5, 0, 0, 0, time.Local)
		if now.After(updateTime) && now.Before(updateTime.Add(1*time.Minute)) {
			p.klines = nil
			Logger.Info("更新均线")
			return
		} else {

			ticker := p.fxcm.GetTicker(p.config.Pair)
			if ticker == nil {
				Logger.Errorf("无法获取最新价格")
				return
			}
			Logger.Infof("当前价格:%.5f %v", ticker.Last, ticker)

			p.klines[len(p.klines)-1].High = ticker.High
			p.klines[len(p.klines)-1].Low = ticker.Low
			p.klines[len(p.klines)-1].Close = ticker.Last

		}
	}

	// p.speed.CheckSpeed(p.klines[len(p.klines)-1].Close)

	kline := p.klines
	if kline == nil || len(kline) < 20 {
		Logger.Errorf("无效K线数据")
		return
	}

	length := len(kline)
	current := kline[length-1]

	Logger.Infof("[High]%.5f [Open]%.5f [Close]%.5f [Low]%.5f [Volumn]%.5f", current.High, current.Open, current.Close, current.Low, current.Volumn)
	Logger.Infof("服务器时间:%d[%s] 当前时间:%d[%s]",
		int(current.OpenTime), time.Unix(int64(current.OpenTime), 0).Format(Global.TimeFormat),
		time.Now().Unix(), time.Now().Format(Global.TimeFormat))

	// 是否需要减仓,外汇日线比较平滑，所以用均线会更好一些
	if p.CheckAverageClosePosition(kline) {
		p.adjustDuration(true)
		return
	}

	// 资金管理
	amount := p.checkFunds(current.Close)
	if amount == 0 {
		Logger.Info("无可用仓位...不开仓")
		p.adjustDuration(false)
		return
	}

	if true {
		if p.checkBreakPosition(kline, amount) {
			p.adjustDuration(true)
		}
	}
}

func (p *FXCMTrend) checkBreakPosition(kline []Exchange.KlineValue, amount float64) bool {
	err, high, low := p.getLastPeriodArea(kline)
	if err != nil {
		Logger.Errorf("Error in getLastPeriodArea():%s", err.Error())
		return false
	}

	length := len(kline)
	current := kline[length-1]

	array5 := kline[length-5 : length]
	array10 := kline[length-10 : length]

	avg5 := Exchange.GetAverage(5, array5)
	avg10 := Exchange.GetAverage(10, array10)

	Logger.Infof("前一个周期波动区间 High: %.5f Low: %.5f Avg5: %.5f Avg10: %.5f", high, low, avg5, avg10)

	// 有可能假突破
	if (current.Close > high) && (avg5 > avg10) &&
		p.config.OpenLong {

		// ticker := p.fxcm.GetTicker(p.config.Pair)

		Logger.Infof("突破前期高点做多")

		batch := Utils.GetRandomHexString(12)
		timestamp := int64(current.OpenTime)
		p.openPosition(timestamp, Exchange.TradeConfig{
			Batch: batch,
			Pair:  p.config.Pair,
			Type:  Exchange.TradeTypeOpenLong,
			// Price:  ticker.Last,
			Amount: amount,
			Limit:  p.config.LimitOpenRatio,
		})
		return true

	} else if (current.Close < low) && (avg5 < avg10) &&
		p.config.OpenShort {

		Logger.Infof("突破前期低点做空")

		batch := Utils.GetRandomHexString(12)
		timestamp := int64(current.OpenTime)
		p.openPosition(timestamp, Exchange.TradeConfig{
			Batch: batch,
			Pair:  p.config.Pair,
			Type:  Exchange.TradeTypeOpenShort,
			// Price:  bidFuturePlacePrice,
			Amount: amount,
			Limit:  p.config.LimitOpenRatio,
		})
		return true
	}

	return false
}

func (p *FXCMTrend) adjustDuration(hasTrade bool) {

	if hasTrade {
		if p.checkPeriodSec == FXCMCheckingPeriodMS {
			Logger.Debugf("检测周期变成%d毫秒", FXCMCheckingPeriodMS)
			p.checkPeriodSec = FXCMTradingPeriodMS
		}
	} else {
		if p.checkPeriodSec == FXCMTradingPeriodMS {
			// 5 minutes without trading
			Logger.Debugf("检测周期变成%d毫秒", FXCMCheckingPeriodMS)
			p.checkPeriodSec = FXCMCheckingPeriodMS
		}
	}
}

func (p *FXCMTrend) openPosition(timestamp int64, tradeConfig Exchange.TradeConfig) {

	channelFuture := FXCMProcessTradeRoutine(p.fxcm, tradeConfig, nil)

	var waitGroup sync.WaitGroup
	var futureResult FXCMTradeResult

	waitGroup.Add(1)
	go func() {
		select {
		case futureResult = <-channelFuture:
			Logger.Debugf("交易结果:%v", futureResult)
			waitGroup.Done()
		}
	}()

	waitGroup.Wait()

	tradeConfig.Batch = futureResult.TradeID
	if err := p.tradeManager.OpenPosition(tradeConfig.Batch,
		timestamp,
		tradeConfig.Pair,
		tradeConfig.Type,
		futureResult.AvgPrice,
		futureResult.DealAmount); err != nil {
		Logger.Error("Fail to save fund info")
	}

	if futureResult.Error == Task.TaskErrorSuccess {
		var position TrendPosition
		var config Exchange.TradeConfig
		config.Batch = tradeConfig.Batch
		config.Amount = futureResult.DealAmount
		config.Limit = tradeConfig.Limit
		config.Pair = tradeConfig.Pair
		config.Type = tradeConfig.Type
		config.Price = futureResult.AvgPrice
		position.TimeStamp = timestamp
		position.Amount = config.Amount
		position.config = config
		p.positions[p.positionIndex] = &position
		p.positionIndex++
	} else {
		// 开仓失败，手工检查
		p.tradeManager.ClosePosition(tradeConfig.Batch, 0, MongoTrend.TradeStatusError)
		p.errorCounter++
		Logger.Errorf("Trade Error:%v", futureResult.Error)
		if p.errorCounter > 100 {
			p.status = Task.StatusError
		}
	}

}

func (p *FXCMTrend) CheckAreaClosePosition(values []Exchange.KlineValue) bool {

	if p.positions == nil || len(p.positions) == 0 {
		return false
	}

	length := len(values)
	current := values[length-1]
	closePrice := current.Close

	for index, position := range p.positions {
		var limitClosePrice float64
		var openLongFlag bool
		var closeFlag bool
		config := position.config
		Logger.Debugf("仓位配置:%v", config)

		if config.Type == Exchange.TradeTypeBuy || config.Type == Exchange.TradeTypeOpenLong {
			limitClosePrice = config.Price * (1 - p.config.LimitCloseRatio)
			openLongFlag = true
		} else if config.Type == Exchange.TradeTypeSell || config.Type == Exchange.TradeTypeOpenShort {
			limitClosePrice = config.Price * (1 + p.config.LimitCloseRatio)
			openLongFlag = false
		} else {
			Logger.Errorf("无效的交易类型")
			continue
		}

		high, low, err := Exchange.GetCurrentPeriodArea(values)
		if err != nil {
			Logger.Errorf("Fail to get current area:%s", err.Error())
			return false
		}

		// log.Printf("当前波动区间 高:%.2f 低:%.2f", high, low)

		offset := 0.21

		// if (high-low)*100/low < 3 {
		// 	logger.Infof("波动太小不操作")
		// 	return false, 0
		// }

		array5 := values[length-5 : length]
		array10 := values[length-10 : length]

		avg5 := Exchange.GetAverage(5, array5)
		avg10 := Exchange.GetAverage(10, array10)

		// log.Printf("Avg5:%.2f Avg10:%.2f Avg20:%.2f", avg5, avg10, avg20)

		Logger.Debugf("止损价格:%.5f", limitClosePrice)

		if openLongFlag {
			if closePrice < limitClosePrice {
				closeFlag = true
				goto __DONE
			}
		} else {
			if closePrice > limitClosePrice {
				closeFlag = true
				goto __DONE
			}
		}

		if openLongFlag {

			Logger.Debugf("当前波动区间 高:%.5f 低:%.5f 振幅:%.5f 做多平仓点:%.5f", high, low, (high-low)*100/low, (high - (high-low)*offset))

			if p.forceCloseFlag && p.forceCloseLength > 0 {

				p.forceCloseLength--
				if p.forceCloseLength == 0 {
					p.forceCloseFlag = false
				}

				Logger.Debugf("手工强制平仓")
				// placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if (high-low)*100/low > 2 && (closePrice < (high - (high-low)*offset)) {
				// placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if avg5 > avg10 {

			} else {
				Logger.Debugf("做多趋势破坏平仓")
				closeFlag = true
				goto __DONE
			}

		} else {

			Logger.Debugf("当前波动区间 高:%.5f 低:%.5f 振幅:%.5f 做空平仓点:%.5f", high, low, (high-low)*100/high, (low + (high-low)*offset))

			if p.forceCloseFlag && p.forceCloseLength > 0 {

				p.forceCloseLength--
				if p.forceCloseLength == 0 {
					p.forceCloseFlag = false
				}

				Logger.Debugf("手工强制平仓")
				// placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if (high-low)*100/low > 2 && (closePrice > (low + (high-low)*offset)) {
				// placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if avg5 < avg10 {

			} else {
				log.Printf("做空趋势破坏平仓")
				closeFlag = true
				goto __DONE
			}
		}
	__DONE:
		if closeFlag {

			config := position.config
			// config.Price = placeClosePrice
			config.Type = Exchange.RevertTradeType(config.Type)
			channelFuture := FXCMProcessTradeRoutine(p.fxcm, config, nil)

			var waitGroup sync.WaitGroup
			var futureResult FXCMTradeResult

			waitGroup.Add(1)
			go func() {
				select {
				case futureResult = <-channelFuture:
					Logger.Debugf("交易结果:%v", futureResult)
					waitGroup.Done()
				}
			}()

			waitGroup.Wait()

			if futureResult.Error == Task.TaskErrorSuccess {
				Logger.Infof("平仓成功")
				delete(p.positions, index)
				p.tradeManager.ClosePosition(config.Batch, futureResult.AvgPrice, MongoTrend.TradeStatusClose)

				if len(p.positions) == 0 {
					Logger.Infof("全部平仓,无仓位")
					p.adjustDuration(false)
					p.balance = 0
					p.forceCloseFlag = false
					p.forceAddFlag = false
					p.forcePartialBalance = 1
					return false
				}
			} else {
				Logger.Infof("平仓失败")
				delete(p.positions, index)
				p.tradeManager.ClosePosition(config.Batch, futureResult.AvgPrice, MongoTrend.TradeStatusError)
				p.errorCounter++
				Logger.Errorf("Trade Error:%v", futureResult.Error)
				if p.errorCounter > 100 {
					p.status = Task.StatusError
				}
			}

			return true
		}

		return false
	}

	return false
}

func (p *FXCMTrend) CheckAverageClosePosition(values []Exchange.KlineValue) bool {

	if p.positions == nil || len(p.positions) == 0 {
		return false
	}

	length := len(values)
	current := values[length-1]
	closePrice := current.Close
	highPrice := current.High
	lowPrice := current.Low

	for index, position := range p.positions {
		var limitClosePrice float64
		var openLongFlag bool
		var closeFlag bool
		config := position.config
		Logger.Debugf("仓位配置:%v", config)

		if config.Type == Exchange.TradeTypeBuy || config.Type == Exchange.TradeTypeOpenLong {
			limitClosePrice = config.Price * (1 - p.config.LimitCloseRatio)
			openLongFlag = true
		} else if config.Type == Exchange.TradeTypeSell || config.Type == Exchange.TradeTypeOpenShort {
			limitClosePrice = config.Price * (1 + p.config.LimitCloseRatio)
			openLongFlag = false
		} else {
			Logger.Errorf("无效的交易类型")
			continue
		}

		timeFlag := false
		now := time.Now()
		updateTime := time.Date(now.Year(), now.Month(), now.Day(), 4, 55, 0, 0, time.Local)
		if now.After(updateTime) && now.Before(updateTime.Add(5*time.Minute)) {
			Logger.Debug("接受破位平仓时间")
			timeFlag = true
		}

		array5 := values[length-5 : length]
		array10 := values[length-10 : length]

		avg5 := Exchange.GetAverage(5, array5)
		avg10 := Exchange.GetAverage(10, array10)

		// log.Printf("Avg5:%.2f Avg10:%.2f Avg20:%.2f", avg5, avg10, avg20)

		Logger.Debugf("止损价格:%.5f", limitClosePrice)

		if openLongFlag {
			if closePrice < limitClosePrice {
				closeFlag = true
				goto __DONE
			}
		} else {
			if closePrice > limitClosePrice {
				closeFlag = true
				goto __DONE
			}
		}

		if openLongFlag {

			if p.forceCloseFlag && p.forceCloseLength > 0 {

				p.forceCloseLength--
				if p.forceCloseLength == 0 {
					p.forceCloseFlag = false
				}

				Logger.Debugf("手工强制平仓")
				// placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if avg5 > avg10 {

			} else {
				Logger.Debugf("做多趋势破坏平仓")
				closeFlag = true
				goto __DONE
			}

			if closePrice < avg10 {
				Logger.Debugf("突破十日线平仓")
				closeFlag = true
				goto __DONE
			}

			// if closePrice < avg10 {
			// 价格柱三分之一突破十日均线平仓
			if (closePrice < avg5) && (highPrice-avg5) < (avg5-lowPrice) && timeFlag {
				Logger.Debugf("突破五日线平仓")
				closeFlag = true
				goto __DONE
			}

		} else {

			if p.forceCloseFlag && p.forceCloseLength > 0 {

				p.forceCloseLength--
				if p.forceCloseLength == 0 {
					p.forceCloseFlag = false
				}

				Logger.Debugf("手工强制平仓")
				// placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if avg5 < avg10 {

			} else {
				log.Printf("做空趋势破坏平仓")
				closeFlag = true
				goto __DONE
			}

			if closePrice > avg10 {
				Logger.Debugf("突破十日线平仓")
				closeFlag = true
				goto __DONE
			}

			// if closePrice > avg10 {
			// 当前价格高于十日均线并且突出长度大于当天价格柱的1/3
			if (closePrice > avg5) && (highPrice-avg5) > (avg5-lowPrice) && timeFlag {
				log.Printf("突破五日线平仓")
				closeFlag = true
				goto __DONE
			}
		}
	__DONE:
		if closeFlag {

			config := position.config
			// config.Price = placeClosePrice
			config.Type = Exchange.RevertTradeType(config.Type)
			channelFuture := FXCMProcessTradeRoutine(p.fxcm, config, nil)

			var waitGroup sync.WaitGroup
			var futureResult FXCMTradeResult

			waitGroup.Add(1)
			go func() {
				select {
				case futureResult = <-channelFuture:
					Logger.Debugf("交易结果:%v", futureResult)
					waitGroup.Done()
				}
			}()

			waitGroup.Wait()

			if futureResult.Error == Task.TaskErrorSuccess {
				Logger.Infof("平仓成功")
				delete(p.positions, index)
				p.tradeManager.ClosePosition(config.Batch, futureResult.AvgPrice, MongoTrend.TradeStatusClose)

				if len(p.positions) == 0 {
					Logger.Infof("全部平仓,无仓位")
					p.adjustDuration(false)
					p.balance = 0
					p.forceCloseFlag = false
					p.forceAddFlag = false
					p.forcePartialBalance = 1
					return false
				}
			} else {
				Logger.Infof("平仓失败")
				delete(p.positions, index)
				p.tradeManager.ClosePosition(config.Batch, futureResult.AvgPrice, MongoTrend.TradeStatusError)
				p.errorCounter++
				Logger.Errorf("Trade Error:%v", futureResult.Error)
				if p.errorCounter > 100 {
					p.status = Task.StatusError
				}
			}

			return true
		}

		return false
	}

	return false
}

func (p *FXCMTrend) getLastPeriodArea(kline []Exchange.KlineValue) (err error, high float64, low float64) {

	var start int
	found := false

	length := len(kline)
	array10 := kline[length-10 : length]
	array20 := kline[length-20 : length]

	avg10 := Exchange.GetAverage(10, array10)
	avg20 := Exchange.GetAverage(20, array20)

	var isOpenLong bool
	if avg10 > avg20 {
		isOpenLong = true
	} else {
		isOpenLong = false
	}

	if isOpenLong {

		step := 0
		for i := len(kline) - 1; i >= 0; i-- {

			if i-20 < 0 {
				start = i
				found = true
				break
			}

			array10 := kline[i-10 : i]
			array20 := kline[i-20 : i]

			avg10 := Exchange.GetAverage(10, array10)
			avg20 := Exchange.GetAverage(20, array20)

			if step == 0 {
				if avg10 < avg20 {
					step = 1
					continue
				}
			} else if step == 1 {
				if avg10 > avg20 {
					step = 2
					continue
				}
			} else if step == 2 {
				if avg10 < avg20 {
					start = i
					found = true
					break
				}
			}
		}

	} else {
		step := 0
		for i := len(kline) - 1; i >= 0; i-- {

			if i-20 < 0 {
				start = i
				found = true
				break
			}

			array10 := kline[i-10 : i]
			array20 := kline[i-20 : i]

			avg10 := Exchange.GetAverage(10, array10)
			avg20 := Exchange.GetAverage(20, array20)

			if step == 0 {
				if avg10 > avg20 {
					step = 1
					continue
				}
			} else if step == 1 {
				if avg10 < avg20 {
					step = 2
					continue
				}
			} else if step == 2 {
				if avg10 > avg20 {
					start = i
					found = true
					break
				}
			}
		}
	}

	if found {
		high = 0
		low = 0
		// Logger.Infof("区间起点:%v", time.Unix(int64(kline[start].OpenTime), 0))
		for i := start; i < len(kline)-1; i++ {
			tmp := (kline[i].High*0.2 + kline[i].Close*0.8)
			if high == 0 {
				high = tmp
			} else if high < tmp {
				high = tmp
			}

			tmp = (kline[i].Low*0.2 + kline[i].Close*0.8)
			if low == 0 {
				low = tmp
			} else if low > tmp {
				low = tmp
			}
		}

		return nil, high, low

	}

	return errors.New("Perios is not Found"), 0, 0

}

func (p *FXCMTrend) ForceClosePositions(ratio int) {

	Logger.Errorf("强制平仓")

	if p.positions == nil || len(p.positions) == 0 {
		return
	}

	p.forceCloseLength = len(p.positions) / ratio
	p.forcePartialBalance = 1 - 1/float64(ratio)
	p.forceCloseFlag = true

}

func (p *FXCMTrend) ForceAddPositions() {
	Logger.Error("强制加仓，慎用!!!")
	p.forceAddFlag = true
}

func FXCMProcessTradeRoutine(exchange *Exchange.FXCM,
	tradeConfig Exchange.TradeConfig,
	dbTrades *Mongo.Trades) chan FXCMTradeResult {

	channel := make(chan FXCMTradeResult)
	Logger.Debugf("Trade Params:%v", tradeConfig)

	go func() {
		defer close(channel)

		var trade *Exchange.TradeResult
		var errorCode Task.TaskErrorType

		var tradePrice, tradeAmount float64

		for {

			// tradePrice = getPlacedPrice(tradeConfig.Type, tradeConfig.Price, tradeConfig.Limit)

			trade = exchange.Trade(Exchange.TradeConfig{
				Batch:  tradeConfig.Batch,
				Pair:   tradeConfig.Pair,
				Type:   tradeConfig.Type,
				Amount: tradeConfig.Amount,
				// Price:  tradePrice,
			})

			if dbTrades != nil {
				if err := dbTrades.Insert(&Mongo.TradesRecord{
					Batch:    tradeConfig.Batch,
					Oper:     Exchange.TradeTypeString[tradeConfig.Type],
					Exchange: exchange.GetExchangeName(),
					Pair:     tradeConfig.Pair,
					Quantity: tradeAmount,
					Price:    tradePrice,
					OrderID:  trade.OrderID,
				}); err != nil {
					Logger.Errorf("保存交易操作失败:%v", err)
				}
			}

			if trade != nil && trade.Error == nil {

				positions := exchange.GetOpenPositions()

				if dbTrades != nil {
					dbTrades.SetDone(trade.OrderID)
				}

				if positions != nil && len(positions) > 0 {
					channel <- FXCMTradeResult{
						Error:      Task.TaskErrorSuccess,
						DealAmount: positions[0].DealAmount,
						AvgPrice:   positions[0].AvgPrice,
						TradeID:    positions[0].OrderID,
					}
					return
				} else {
					Logger.Errorf("无法获取持仓")
					errorCode = Task.TaskUnableTrade
					channel <- FXCMTradeResult{
						Error: errorCode,
					}
					return
				}

			} else {
				Logger.Errorf("交易失败：%v", trade.Error)
				errorCode = Task.TaskUnableTrade
				channel <- FXCMTradeResult{
					Error: errorCode,
				}
				return
			}
		}
	}()

	return channel

}
