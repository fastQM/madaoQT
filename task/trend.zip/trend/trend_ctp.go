package trend

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"os"
	"sync"
	"syscall"
	"time"

	Global "madaoQT/config"
	Exchange "madaoQT/exchange"
	Mongo "madaoQT/mongo"
	MongoTrend "madaoQT/mongo/trend"
	Task "madaoQT/task"
	Utils "madaoQT/utils"

	"golang.org/x/crypto/ssh/terminal"
)

// 期货交易夜盘交易时间
// 上 期 所
// 【黄金AU、白银AG】
// 周一～周五 21:00-次日2:30
// 【铜CU、铝AL、锌ZN、铅PB、锡SN、镍NI】
// 周一～周五21:00-次日1:00
// 【天然橡胶RU、螺纹钢RB、热轧卷板HC、石油沥青BU】
// 周一～周五21:00-23:00
// 大 商 所
// 【棕榈油P、焦炭J、豆粕M、豆油Y、黄大豆一号A、黄大豆二号B、焦煤JM、铁矿石I】
// 周一～周五21:00-23:30
// 郑 商 所
// 【白糖SR、棉花CF、菜粕RM、甲醇MA、PTA、动力煤ZC、玻璃FG、菜籽油OI】
// 周一～周五21:00-23:30

var RealCTPConfig = map[string]interface{}{
	"marketaddr": "tcp://180.168.212.228:41213",
	"tradeaddr":  "tcp://180.168.212.228:41205",
	"broker":     "8080",
	"instruments": []map[string]interface{}{
		// {"name": "v1809"},  // PVC
		{"name": "rb1810"}, // 螺纹钢
		// {"name": "AP810"},  // 苹果
		// {"name": "CF809"},  // 棉花
		// // {"name": "m1809"},  // 豆粨,好多编码搞不懂啊
		// {"name": "i1809"},  // 铁矿
		// {"name": "c1809"},  // 玉米
		// {"name": "l1809"},  // 塑料
		// {"name": "jd1809"}, // 鸡蛋
		// // {"name": "O1809"},  // 菜油
		// {"name": "MA809"}, // 甲醇
		// // {"name": "SR809"}, // 白糖
		// {"name": "ZC809"}, // 郑煤
		{"name": "FG809"}, // 玻璃
	},
}

var SimulateCTPConfig = map[string]interface{}{
	"marketaddr": "tcp://180.168.146.187:10010",
	"tradeaddr":  "tcp://180.168.146.187:10000",
	"broker":     "9999",
	"instruments": []map[string]interface{}{
		{"name": "v1810"},
		// {"name": "CF901"},
		// {"name": "AP810"},
		// {"name": "AP901"},
	},
}

var CTPDefaultConfig = TrendConfig{
	Pair:            "eth/usdt",
	Interval:        Exchange.KlinePeriod1Day,
	OpenLong:        true,
	OpenShort:       true,
	UnitAmount:      1,
	LimitCloseRatio: 0.06,
	LimitOpenRatio:  0.002,
	LossLimit:       0.2,
	FundRatio:       0.1,
}

// 1. 只做和大趋势相同的方向，即上升通道不做空，下降通道不做多

// TrendCTP 策略适用于在短期内(1-3天)出现大幅波动(10%-30%)的市场
type TrendCTP struct {
	config TrendConfig

	Ctpdll *Exchange.CTPDll
	sina   *Exchange.SinaCTP

	status       Task.StatusType
	database     *MongoTrend.TrendMongo
	tradeManager *TradeManager
	balance      float64

	klines map[string][]Exchange.KlineValue

	positions     map[string]interface{}
	positionIndex uint

	instruments map[string]interface{}

	checkPeriodSec time.Duration

	// 强制平仓
	forceCloseFlag   bool
	forceCloseLength int
	// 部分平仓后可建仓位
	forcePartialBalance float64
	forceAddFlag        bool

	errorCounter int

	exit chan bool
}

func getPrefix(instrument string) string {
	data := []byte(instrument)
	var prefix []byte

	for i := 0; i < len(data); i++ {
		if (data[i] >= 'a' && data[i] <= 'z') ||
			(data[i] >= 'A' && data[i] <= 'Z') {
			prefix = append(prefix, data[i])
		} else {
			break
		}
	}

	return string(prefix)
}

func (p *TrendCTP) GetDescription() Task.Description {

	return Task.Description{
		Name:  "商品期货趋势交易",
		Title: "商品期货的趋势策略",
		Desc:  "该策略主要跟踪大幅上涨或者下跌的趋势",
	}
}

func (p *TrendCTP) GetDefaultConfig() interface{} {
	return CTPDefaultConfig
}
func (p *TrendCTP) GetBalances(coin string) map[string]interface{} {
	return nil
}
func (p *TrendCTP) GetTrades() []Mongo.TradesRecord {
	return nil
}

func (p *TrendCTP) GetPositions(instrument string) map[string]interface{} {
	return p.Ctpdll.GetPositionInfo(instrument)
}

func (p *TrendCTP) GetInstrumentsInfo() {

}

func (p *TrendCTP) GetInstrumentInfo() {
	for _, instrument := range RealCTPConfig["instruments"].([]map[string]interface{}) {
		Utils.SleepAsyncBySecond(1)
		name := instrument["name"].(string)
		info := p.Ctpdll.GetInstrumentInfo(name)
		if info != nil && len(info) > 0 {
			p.instruments[name] = info
		}

	}
}

func (p *TrendCTP) GetPositionInfo() {
	for _, instrument := range RealCTPConfig["instruments"].([]map[string]interface{}) {
		Utils.SleepAsyncBySecond(1)
		name := instrument["name"].(string)
		info := p.Ctpdll.GetPositionInfo(name)
		if info != nil && len(info) > 0 {
			p.positions[name] = info
		}

	}
}

func (p *TrendCTP) Close() {
	p.exit <- true
	return
}

func (p *TrendCTP) GetStatus() Task.StatusType {
	return p.status
}

func (p *TrendCTP) Start(configJSON string) error {

	Logger.Infof("%s", trendTaskExplaination)

	if configJSON == "" {
		p.config = p.GetDefaultConfig().(TrendConfig)
	} else {
		var config TrendConfig
		err := json.Unmarshal([]byte(configJSON), &config)
		if err != nil {
			log.Printf("Fail to get config:%v", err)
			return errors.New(Task.TaskErrorMsg[Task.TaskInvalidConfig])
		}
		p.config = config
	}

	setting := RealCTPConfig

	fmt.Print("请输入投资者账号:\r\n")
	key, err := terminal.ReadPassword(int(syscall.Stdin))
	if err != nil {
		return err
	}

	setting["investor"] = string(key)

	fmt.Print("请输入投资者密码:\r\n")
	key, err = terminal.ReadPassword(int(syscall.Stdin))
	if err != nil {
		return err
	}

	setting["password"] = string(key)

	var configS []byte
	if configS, err = json.Marshal(setting); err != nil {
		return err
	}

	if !p.Ctpdll.SetConfig(string(configS)) {
		return errors.New("Fail to config CTP")
	}

	Logger.Info("===========配置(CTP)=====================")
	Logger.Infof("检测周期:%v(分钟)", p.config.Interval)
	Logger.Infof("下单单位:%v(手)", p.config.UnitAmount)
	Logger.Infof("是否开空:%v, 是否开多:%v", p.config.OpenLong, p.config.OpenShort)
	Logger.Infof("交易记录数据库名：%s", Task.TrendTradeCollectionCTP)
	Logger.Infof("资金数据库名:%s", Task.TrendBalanceCTP)
	Logger.Info("==========================================")

	p.status = Task.StatusProcessing
	p.checkPeriodSec = CheckingPeriodMS
	p.forcePartialBalance = 1.0
	p.klines = make(map[string][]Exchange.KlineValue)
	p.instruments = make(map[string]interface{})
	p.positions = make(map[string]interface{})
	p.exit = make(chan bool)

	p.sina = new(Exchange.SinaCTP)

	go func() {
		Logger.Infof("启动价格监视线程")
		p.Ctpdll.InitMarket()
	}()

	go func() {
		Logger.Infof("启动交易线程")
		p.Ctpdll.InitTrade()
	}()

	// 等待初始化完成
	Utils.SleepAsyncBySecond(5)
	Logger.Infof("获取商品信息数据")
	p.GetInstrumentInfo()
	Utils.SleepAsyncBySecond(5)
	Logger.Infof("获取持仓数据")
	p.GetPositionInfo()
	Utils.SleepAsyncBySecond(5)

	go func() {
		for {
			select {
			case <-time.After(p.checkPeriodSec * time.Millisecond):
				if p.status == Task.StatusError || p.status == Task.StatusNone {
					Logger.Debug("状态异常或退出")
					return
				}

				now := time.Now()
				period_start1 := time.Date(now.Year(), now.Month(), now.Day(), 9, 0, 0, 0, time.Local)
				period_end1 := time.Date(now.Year(), now.Month(), now.Day(), 11, 30, 0, 0, time.Local)

				period_start2 := time.Date(now.Year(), now.Month(), now.Day(), 13, 30, 0, 0, time.Local)
				period_end2 := time.Date(now.Year(), now.Month(), now.Day(), 15, 00, 0, 0, time.Local)

				period_start3 := time.Date(now.Year(), now.Month(), now.Day(), 21, 30, 0, 0, time.Local)
				period_end3 := time.Date(now.Year(), now.Month(), now.Add(24*time.Hour).Day(), 2, 30, 0, 0, time.Local)

				if now.After(period_start1) && now.Before(period_end1) ||
					(now.After(period_start2) && now.Before(period_end2)) ||
					(now.After(period_start3) && now.Before(period_end3)) {

				} else {
					log.Printf("不在交易时间")
					// os.Exit(0)
				}

				if p.Ctpdll.GetStatus() == Exchange.CTPStatusDisconnect || p.Ctpdll.GetStatus() == Exchange.CTPStatusError {
					Logger.Error("连接断开或者错误")
					os.Exit(0)
				}

				// p.database.Refresh()
				for _, instrument := range RealCTPConfig["instruments"].([]map[string]interface{}) {
					Utils.SleepAsyncBySecond(1)
					p.Watch(instrument["name"].(string))
				}
			case <-p.exit:
				return

			}
		}
	}()

	return nil
}

func (p *TrendCTP) loadPosition() {
}

func (p *TrendCTP) checkFunds(instrument string, latestPrice float64) float64 {
	if p.balance == 0 {
		balance := p.Ctpdll.GetBalance()
		if balance != nil {
			p.balance = balance["Available"].(float64)
		}
	}

	instrumentInfo := p.instruments[instrument]
	if instrumentInfo == nil || len(instrumentInfo.(map[string]interface{})) == 0 {
		Logger.Error("无效商品信息")
		return 0
	}

	request := p.config.UnitAmount * latestPrice * (instrumentInfo.(map[string]interface{})["VolumeMultiple"].(float64)) * (instrumentInfo.(map[string]interface{})["LongMarginRatio"].(float64) + instrumentInfo.(map[string]interface{})["ShortMarginRatio"].(float64))

	var openPosition float64
	if p.positions[instrument] != nil {
		position := p.positions[instrument].(map[string]interface{})
		openPosition = position["Position"].(float64)
	}

	Logger.Infof("当前余额:%.2f 开仓金额:%.2f 已开仓:%.2f", p.balance, request, openPosition)

	if p.balance > request && openPosition == 0 {
		return p.config.UnitAmount
	}

	return 0
}

func (p *TrendCTP) Watch(instrument string) {

	location, _ := time.LoadLocation("Asia/Shanghai")

	prefix := getPrefix(instrument) + "0"
	Logger.Debugf("=====当前检测商品:%s 前缀:%s=====", instrument, prefix)

	if p.klines[prefix] == nil || len(p.klines[prefix]) == 0 {
		p.klines[prefix] = p.sina.GetKline(prefix, time.Now(), nil, 0)
		if p.klines[prefix] == nil {
			Logger.Errorf("未获取均线信息")
			return
		}
	} else {

		now := time.Now().In(location)
		updateTime := time.Date(now.Year(), now.Month(), now.Day(), 9, 0, 0, 0, location)
		if now.After(updateTime) && now.Before(updateTime.Add(1*time.Minute)) {
			p.klines[prefix] = nil
			Logger.Info("更新均线")
			p.forceCloseFlag = false
			return
		} else {
			current := p.klines[prefix][len(p.klines[prefix])-1]
			depth := p.Ctpdll.GetDepth(instrument)
			if depth == nil {
				Logger.Error("无法获取最新价格")
				return
			}

			updateTime, err := time.Parse("15:04:05", depth["updateTime"].(string))
			if err != nil {
				Logger.Errorf("时间格式错误:%v", err)
				return
			}

			checkTime := time.Date(now.Year(), now.Month(), now.Day(),
				updateTime.Hour(), updateTime.Minute(), updateTime.Second(), 0,
				location)

			if checkTime.Before(time.Now().Add(10*time.Second)) && checkTime.After(time.Now().Add(-10*time.Second)) {

			} else {
				Logger.Debugf("价格更新时间无效:%v", checkTime.String())
				return
			}

			askPrice := depth["ask"].(float64)
			bidPrice := depth["bid"].(float64)

			Logger.Infof("[%s]当前深度价格:%.2f %.2f", instrument, askPrice, bidPrice)
			// 挂的买单高于现有当前最高价才算最高价
			if bidPrice > current.High {
				p.klines[prefix][len(p.klines[prefix])-1].High = bidPrice
			}

			if askPrice < current.Low {
				p.klines[prefix][len(p.klines[prefix])-1].Low = askPrice
			}

			p.klines[prefix][len(p.klines[prefix])-1].Close = (askPrice + bidPrice) / 2
		}
	}

	kline := p.klines[prefix]
	if kline == nil || len(kline) < 20 {
		Logger.Errorf("无效K线数据")
		return
	}

	length := len(kline)
	current := kline[length-1]

	Logger.Infof("[High]%.2f [Open]%.2f [Close]%.2f [Low]%.2f [Volumn]%.2f", current.High, current.Open, current.Close, current.Low, current.Volumn)
	Logger.Infof("服务器时间:%s 当前时间:[%s]",
		current.Time,
		time.Now().In(location).Format(Global.TimeFormat))

	// var timeFlag bool
	// if time.Now().Unix()-int64(current.OpenTime) > 240 {
	// 	timeFlag = true
	// }

	// 是否需要减仓
	if p.CheckAreaClosePosition(instrument, kline) {
		p.adjustDuration(true)
		return
	}

	// 资金管理
	amount := p.checkFunds(instrument, current.Close)
	if amount == 0 {
		Logger.Info("无可用仓位...不开仓")
		p.adjustDuration(false)
		return
	}

	if true {
		if p.checkBreakPosition(instrument, kline, amount) {
			p.adjustDuration(true)
		}
	}
}

func (p *TrendCTP) checkBreakPosition(instrument string, kline []Exchange.KlineValue, amount float64) bool {
	err, high, low := p.getLastPeriodArea(kline)
	if err != nil {
		Logger.Errorf("Error in getLastPeriodArea():%s", err.Error())
		return false
	}

	length := len(kline)
	current := kline[length-1]

	array5 := kline[length-5 : length]
	array10 := kline[length-10 : length]

	avg5 := Exchange.GetAverage(5, array5)
	avg10 := Exchange.GetAverage(10, array10)

	Logger.Infof("前一个周期波动区间 High: %.2f Low: %.2f Avg5: %.2f Avg10: %.2f", high, low, avg5, avg10)

	if p.forceCloseFlag == true {
		Logger.Debug("减仓当前周期不加仓")
		return false
	}

	// 有可能假突破
	if (current.Close > high) && (avg5 > avg10) && p.config.OpenLong {

		depth := p.Ctpdll.GetDepth(instrument)
		if depth == nil {
			Logger.Error("无法获取最新价格")
			return false
		}

		askPrice := depth["ask"].(float64)

		Logger.Infof("突破前期高点,做多价格:%.2f", askPrice)
		batch := Utils.GetRandomHexString(12)
		timestamp := int64(current.OpenTime)
		p.openPosition(timestamp, Exchange.TradeConfig{
			Batch:  batch,
			Pair:   instrument,
			Type:   Exchange.TradeTypeOpenLong,
			Price:  askPrice,
			Amount: amount,
		})
		return true

	} else if (current.Close < low) && (avg5 < avg10) && p.config.OpenShort {
		depth := p.Ctpdll.GetDepth(instrument)
		if depth == nil {
			Logger.Error("无法获取最新价格")
			return false
		}
		bidPrice := depth["bid"].(float64)

		Logger.Infof("突破前期低点加仓，做空价格:%.2f", bidPrice)

		batch := Utils.GetRandomHexString(12)
		timestamp := int64(current.OpenTime)
		p.openPosition(timestamp, Exchange.TradeConfig{
			Batch:  batch,
			Pair:   instrument,
			Type:   Exchange.TradeTypeOpenShort,
			Price:  bidPrice,
			Amount: amount,
		})
		return true
	}

	return false
}

func (p *TrendCTP) adjustDuration(hasTrade bool) {

	if hasTrade {
		if p.checkPeriodSec == CheckingPeriodMS {
			Logger.Debugf("检测周期变成%d毫秒", TradingPeriodMS)
			p.checkPeriodSec = TradingPeriodMS
		}
	} else {
		if p.checkPeriodSec == TradingPeriodMS {
			// 5 minutes without trading
			Logger.Debugf("检测周期变成%d毫秒", CheckingPeriodMS)
			p.checkPeriodSec = CheckingPeriodMS
		}
	}
}

func (p *TrendCTP) openPosition(timestamp int64, tradeConfig Exchange.TradeConfig) {

	channelFuture := p.ProcessTradeRoutineIOC(tradeConfig)

	var waitGroup sync.WaitGroup
	var futureResult Task.TradeResult

	waitGroup.Add(1)
	go func() {
		select {
		case futureResult = <-channelFuture:
			Logger.Debugf("交易结果:%v", futureResult)
			waitGroup.Done()
		}
	}()

	waitGroup.Wait()

	if futureResult.Error == Task.TaskErrorSuccess {
		Logger.Debug("开仓成功!!!")
		// 重新获取资金余额
		p.GetPositionInfo()
		p.balance = 0
	} else {
		// 开仓失败，手工检查
		p.errorCounter++
		Logger.Errorf("Trade Error:%v", futureResult.Error)
		if p.errorCounter > 100 {
			p.status = Task.StatusError
		}
	}

}

func (p *TrendCTP) CheckAreaClosePosition(instrument string, values []Exchange.KlineValue) bool {

	length := len(values)
	current := values[length-1]
	closePrice := current.Close
	config := Exchange.TradeConfig{}

	// position := p.Ctpdll.GetPositionInfo(instrument)
	temp := p.positions[instrument]
	if temp != nil {
		position := temp.(map[string]interface{})
		var limitClosePrice, placeClosePrice float64
		var openLongFlag bool
		var closeFlag bool
		var high, low float64
		var err error

		if position["PosiDirection"].(float64) == '2' {
			Logger.Info("持仓为多仓")
			config.Type = Exchange.TradeTypeOpenLong
		} else if position["PosiDirection"].(float64) == '3' {
			Logger.Info("持仓为空仓")
			config.Type = Exchange.TradeTypeOpenShort
		} else {
			Logger.Error("无效的交易类型1")
			return false
		}

		if p.instruments[instrument] != nil {
			instrumentInfo := p.instruments[instrument].(map[string]interface{})
			config.Price = position["OpenCost"].(float64) / (instrumentInfo["VolumeMultiple"].(float64) * position["Position"].(float64))
			Logger.Infof("持仓价格:%.2f", config.Price)
		} else {
			Logger.Error("交易商品信息有误")
			return false
		}

		if config.Type == Exchange.TradeTypeBuy || config.Type == Exchange.TradeTypeOpenLong {

			limitClosePrice = config.Price * (1 - p.config.LimitCloseRatio)
			openLongFlag = true
		} else if config.Type == Exchange.TradeTypeSell || config.Type == Exchange.TradeTypeOpenShort {

			limitClosePrice = config.Price * (1 + p.config.LimitCloseRatio)
			openLongFlag = false
		} else {
			Logger.Errorf("无效的交易类型2")
			return false
		}

		high, low, err = Exchange.GetCurrentPeriodArea(values)
		if err != nil {
			Logger.Errorf("Fail to get current area:%s", err.Error())
			return false
		}

		depth := p.Ctpdll.GetDepth(instrument)
		if depth == nil {
			Logger.Error("无法获取最新价格")
			return false
		}

		askSpotPlacePrice := depth["ask"].(float64)
		bidSpotPlacePrice := depth["bid"].(float64)

		// log.Printf("当前波动区间 高:%.2f 低:%.2f", high, low)

		offset := 0.382

		array5 := values[length-5 : length]
		array10 := values[length-10 : length]

		avg5 := Exchange.GetAverage(5, array5)
		avg10 := Exchange.GetAverage(10, array10)

		if openLongFlag {
			if closePrice < limitClosePrice {
				Logger.Debugf("做多止损,止损价格:%.2f", limitClosePrice)
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
		} else {
			if closePrice > limitClosePrice {
				Logger.Debugf("做空止损,止损价格:%.2f", limitClosePrice)
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
		}

		// if int64(current.OpenTime) == position.TimeStamp {
		// 	Logger.Info("忽略开仓期间的价格波动")
		// 	return false
		// }

		// log.Printf("Avg5:%.2f Avg10:%.2f Avg20:%.2f", avg5, avg10, avg20)

		if openLongFlag {

			Logger.Infof("当前波动区间 高:%.2f 低:%.2f 振幅:%.2f 做多平仓点:%.2f", high, low, (high-low)*100/low, (high - (high-low)*offset))

			if p.forceCloseFlag && p.forceCloseLength > 0 {

				p.forceCloseLength--
				Logger.Debugf("手工强制平仓")
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if (high-low)*100/low > 3 && (closePrice < (high - (high-low)*offset)) {
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if avg5 > avg10 {

			} else {
				Logger.Debugf("做多趋势破坏平仓")
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
		} else {

			Logger.Infof("当前波动区间 高:%.2f 低:%.2f 振幅:%.2f 做空平仓点:%.2f", high, low, (high-low)*100/high, (low + (high-low)*offset))

			if p.forceCloseFlag && p.forceCloseLength > 0 {

				p.forceCloseLength--

				Logger.Debugf("手工强制平仓")
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if (high-low)*100/low > 3 && (closePrice > (low + (high-low)*offset)) {
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if avg5 < avg10 {

			} else {
				Logger.Debugf("做空趋势破坏平仓")
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
		}
	__DONE:
		if closeFlag {
			config.Price = placeClosePrice
			config.Type = Exchange.RevertTradeType(config.Type)
			channelFuture := p.ProcessTradeRoutineIOC(config)

			var waitGroup sync.WaitGroup
			var futureResult Task.TradeResult

			waitGroup.Add(1)
			go func() {
				select {
				case futureResult = <-channelFuture:
					Logger.Debugf("交易结果:%v", futureResult)
					waitGroup.Done()
				}
			}()

			waitGroup.Wait()

			if futureResult.Error == Task.TaskErrorSuccess {
				Logger.Infof("平仓成功，更新持仓数据")
				p.GetPositionInfo()
				p.adjustDuration(false)
				p.balance = 0
				p.forceCloseFlag = true
				p.forceAddFlag = false
				p.forcePartialBalance = 1
				return false
			} else {
				Logger.Infof("平仓失败")
				p.errorCounter++
				Logger.Errorf("Trade Error:%v", futureResult.Error)
				if p.errorCounter > 100 {
					p.status = Task.StatusError
				}
			}

			return true
		}

		return false
	}

	return false
}

// 如果需要平仓，则返回true，后续不再开仓；否则返回false，后续可能开仓
// func (p *TrendCTP) CheckClosePosition(instrument string, values []Exchange.KlineValue, currentKlineStart int) bool {

// 	if p.positions == nil || len(p.positions) == 0 {
// 		return false
// 	}

// 	length := len(values)
// 	current := values[length-1]
// 	highPrice := current.High
// 	lowPrice := current.Low
// 	closePrice := current.Close

// 	position := p.Ctpdll.GetPositionInfo(instrument)
// 	if position != nil {
// 		var lossLimitPrice, placeClosePrice float64
// 		var openLongFlag bool
// 		var closeFlag bool
// 		config := position.config
// 		Logger.Debugf("仓位配置:%v", config)

// 		if int64(current.OpenTime) == position.TimeStamp {
// 			Logger.Info("忽略开仓期间的价格波动")
// 			return false
// 		}

// 		if config.Type == Exchange.TradeTypeBuy || config.Type == Exchange.TradeTypeOpenLong {

// 			if closePrice < config.Price*(1-p.config.LossLimit) {
// 				Logger.Errorf("市场价格异常，请手动操作")
// 				p.errorCounter++
// 				return false
// 			}

// 			lossLimitPrice = config.Price * (1 - p.config.LimitCloseRatio)
// 			// targetProfitPrice = openPrice * (1 + profitLimit)
// 			openLongFlag = true
// 		} else if config.Type == Exchange.TradeTypeSell || config.Type == Exchange.TradeTypeOpenShort {

// 			if closePrice > config.Price*(1+p.config.LossLimit) {
// 				Logger.Errorf("市场价格异常，请手动操作")
// 				p.errorCounter++
// 				return false
// 			}

// 			lossLimitPrice = config.Price * (1 + p.config.LimitCloseRatio)
// 			// targetProfitPrice = openPrice * (1 - lossLimit)
// 			openLongFlag = false
// 		} else {
// 			Logger.Errorf("无效的交易类型")
// 			return false
// 		}

// 		depth := p.Ctpdll.GetDepth(instrument)
// 		if depth == nil {
// 			Logger.Error("无法获取最新价格")
// 			return false
// 		}

// 		askSpotPlacePrice := depth["ask"].(float64)
// 		bidSpotPlacePrice := depth["bid"].(float64)

// 		var timeFlag bool
// 		if time.Now().Unix()-int64(currentKlineStart) > int64(p.config.Interval*60*4/5) {
// 			timeFlag = true
// 		}

// 		if openLongFlag {
// 			if lowPrice < lossLimitPrice {
// 				Logger.Debugf("做多止损,止损价格:%v", lossLimitPrice)
// 				placeClosePrice = bidSpotPlacePrice
// 				closeFlag = true
// 			}
// 		} else {
// 			if highPrice > lossLimitPrice {
// 				Logger.Debugf("做空止损,止损价格:%v", lossLimitPrice)
// 				placeClosePrice = askSpotPlacePrice
// 				closeFlag = true
// 			}
// 		}

// 		array5 := values[length-5 : length]
// 		array10 := values[length-10 : length]
// 		array20 := values[length-20 : length]

// 		avg5 := Exchange.GetAverage(5, array5)
// 		avg10 := Exchange.GetAverage(10, array10)
// 		avg20 := Exchange.GetAverage(20, array20)

// 		Logger.Debugf("[Avg5]%.2f [Avg10]%.2f [Avg20]%.2f", avg5, avg10, avg20)

// 		if openLongFlag {

// 			if p.forceCloseFlag && p.forceCloseLength > 0 {

// 				p.forceCloseLength--
// 				if p.forceCloseLength == 0 {
// 					p.forceCloseFlag = false
// 				}

// 				Logger.Debugf("手工强制平仓")
// 				placeClosePrice = bidSpotPlacePrice
// 				closeFlag = true
// 				goto __DONE
// 			}

// 			if avg5 > avg10 && avg10 > avg20 {

// 			} else {
// 				Logger.Debugf("做多趋势破坏平仓")
// 				placeClosePrice = bidSpotPlacePrice
// 				closeFlag = true
// 				goto __DONE
// 			}

// 			if closePrice < avg10 {
// 				Logger.Debugf("突破十日线平仓")
// 				placeClosePrice = bidSpotPlacePrice
// 				closeFlag = true
// 				goto __DONE
// 			}

// 			// if closePrice < avg10 {
// 			// 价格柱三分之一突破十日均线平仓
// 			if (closePrice < avg5) && (highPrice-avg5) < (avg5-lowPrice) && timeFlag {
// 				Logger.Debugf("突破五日线平仓")
// 				placeClosePrice = bidSpotPlacePrice
// 				closeFlag = true
// 				goto __DONE
// 			}
// 		} else {

// 			if p.forceCloseFlag && p.forceCloseLength > 0 {

// 				p.forceCloseLength--
// 				if p.forceCloseLength == 0 {
// 					p.forceCloseFlag = false
// 				}

// 				Logger.Debugf("手工强制平仓")
// 				placeClosePrice = askSpotPlacePrice
// 				closeFlag = true
// 				goto __DONE
// 			}

// 			if avg5 < avg10 && avg10 < avg20 {

// 			} else {
// 				log.Printf("做空趋势破坏平仓")
// 				placeClosePrice = askSpotPlacePrice
// 				closeFlag = true
// 				goto __DONE
// 			}

// 			if closePrice > avg10 {
// 				Logger.Debugf("突破十日线平仓")
// 				placeClosePrice = askSpotPlacePrice
// 				closeFlag = true
// 				goto __DONE
// 			}

// 			// if closePrice > avg10 {
// 			// 当前价格高于十日均线并且突出长度大于当天价格柱的1/3
// 			if (closePrice > avg5) && (highPrice-avg5) > (avg5-lowPrice) && timeFlag {
// 				log.Printf("突破五日线平仓")
// 				placeClosePrice = askSpotPlacePrice
// 				closeFlag = true
// 				goto __DONE
// 			}
// 		}
// 	__DONE:
// 		if closeFlag {

// 			config := position.config
// 			config.Price = placeClosePrice
// 			config.Type = Exchange.RevertTradeType(config.Type)
// 			channelFuture := p.ProcessTradeRoutineIOC(config, nil)

// 			var waitGroup sync.WaitGroup
// 			var futureResult Task.TradeResult

// 			waitGroup.Add(1)
// 			go func() {
// 				select {
// 				case futureResult = <-channelFuture:
// 					Logger.Debugf("交易结果:%v", futureResult)
// 					waitGroup.Done()
// 				}
// 			}()

// 			waitGroup.Wait()

// 			if futureResult.Error == Task.TaskErrorSuccess {
// 				Logger.Infof("平仓成功")
// 				delete(p.positions, index)
// 				p.tradeManager.ClosePosition(config.Batch, futureResult.AvgPrice, MongoTrend.TradeStatusClose)

// 				if len(p.positions) == 0 {
// 					Logger.Infof("全部平仓,无仓位")
// 					p.adjustDuration(false)
// 					p.balance = 0
// 					p.forceCloseFlag = false
// 					p.forceAddFlag = false
// 					p.forcePartialBalance = 1
// 					return false
// 				}
// 			} else {
// 				Logger.Infof("平仓失败")
// 				p.tradeManager.ClosePosition(config.Batch, futureResult.AvgPrice, MongoTrend.TradeStatusError)
// 				p.errorCounter++
// 				Logger.Errorf("Trade Error:%v", futureResult.Error)
// 				if p.errorCounter > 100 {
// 					p.status = Task.StatusError
// 				}
// 			}

// 			return true
// 		}

// 		return false
// 	}

// 	return false
// }

func (p *TrendCTP) getLastPeriodArea(kline []Exchange.KlineValue) (err error, high float64, low float64) {

	var start int
	found := false

	length := len(kline)
	array10 := kline[length-10 : length]
	array20 := kline[length-20 : length]

	avg10 := Exchange.GetAverage(10, array10)
	avg20 := Exchange.GetAverage(20, array20)

	var isOpenLong bool
	if avg10 > avg20 {
		isOpenLong = true
	} else {
		isOpenLong = false
	}

	if isOpenLong {

		step := 0
		for i := len(kline) - 1; i >= 0; i-- {

			if i-20 < 0 {
				start = i
				found = true
				break
			}

			array10 := kline[i-10 : i]
			array20 := kline[i-20 : i]

			avg10 := Exchange.GetAverage(10, array10)
			avg20 := Exchange.GetAverage(20, array20)

			if step == 0 {
				if avg10 < avg20 {
					step = 1
					continue
				}
			} else if step == 1 {
				if avg10 > avg20 {
					step = 2
					continue
				}
			} else if step == 2 {
				if avg10 < avg20 {
					start = i
					found = true
					break
				}
			}
		}

	} else {
		step := 0
		for i := len(kline) - 1; i >= 0; i-- {

			if i-20 < 0 {
				start = i
				found = true
				break
			}

			array10 := kline[i-10 : i]
			array20 := kline[i-20 : i]

			avg10 := Exchange.GetAverage(10, array10)
			avg20 := Exchange.GetAverage(20, array20)

			if step == 0 {
				if avg10 > avg20 {
					step = 1
					continue
				}
			} else if step == 1 {
				if avg10 < avg20 {
					step = 2
					continue
				}
			} else if step == 2 {
				if avg10 > avg20 {
					start = i
					found = true
					break
				}
			}
		}
	}

	if found {
		high = 0
		low = 0
		// Logger.Infof("区间起点:%v", time.Unix(int64(kline[start].OpenTime), 0))
		// 是否需要包含当前的价格波动?
		for i := start; i < len(kline)-1; i++ {
			tmp := (kline[i].High*0.2 + kline[i].Close*0.8)
			if high == 0 {
				high = tmp
			} else if high < tmp {
				high = tmp
			}

			tmp = (kline[i].Low*0.2 + kline[i].Close*0.8)
			if low == 0 {
				low = tmp
			} else if low > tmp {
				low = tmp
			}
		}

		return nil, high, low

	}

	return errors.New("Perios is not Found"), 0, 0

}

func (p *TrendCTP) ForceClosePositions(ratio int) {

	Logger.Errorf("强制平仓")

	if p.positions == nil || len(p.positions) == 0 {
		return
	}

	p.forceCloseLength = len(p.positions) / ratio
	p.forcePartialBalance = 1 - 1/float64(ratio)
	p.forceCloseFlag = true

}

func (p *TrendCTP) ForceAddPositions() {
	Logger.Error("强制加仓，慎用!!!")
	p.forceAddFlag = true
}

func (p *TrendCTP) ProcessTradeRoutineIOC(tradeConfig Exchange.TradeConfig) chan Task.TradeResult {

	channel := make(chan Task.TradeResult)
	Logger.Debugf("Trade Params:%v", tradeConfig)

	go func() {
		defer close(channel)

		isMarket := 1
		if p.instruments[tradeConfig.Pair] != nil {
			info := p.instruments[tradeConfig.Pair].(map[string]interface{})
			if info["ExchangeID"].(string) == "SHFE" {
				isMarket = 0
			}
		}

		var result map[string]interface{}
		if tradeConfig.Type == Exchange.TradeTypeOpenLong {
			result = p.Ctpdll.MarketOpenPosition(tradeConfig.Pair, int(tradeConfig.Amount), int(tradeConfig.Price), 1, isMarket)
		} else if tradeConfig.Type == Exchange.TradeTypeOpenShort {
			result = p.Ctpdll.MarketOpenPosition(tradeConfig.Pair, int(tradeConfig.Amount), int(tradeConfig.Price), 0, isMarket)
		} else if tradeConfig.Type == Exchange.TradeTypeCloseLong {
			result = p.Ctpdll.MarketClosePosition(tradeConfig.Pair, int(tradeConfig.Amount), int(tradeConfig.Price), 0, isMarket)
		} else if tradeConfig.Type == Exchange.TradeTypeCloseShort {
			result = p.Ctpdll.MarketClosePosition(tradeConfig.Pair, int(tradeConfig.Amount), int(tradeConfig.Price), 1, isMarket)
		}

		if result != nil {

			if result["status"].(string) == "cancel" {
				channel <- Task.TradeResult{
					Error: Task.TaskIOCReturn,
				}
				return
			} else if result["status"].(string) == "error" {
				channel <- Task.TradeResult{
					Error: Task.TaskUnableTrade,
				}
				return
			} else {
				channel <- Task.TradeResult{
					Error: Task.TaskErrorSuccess,
				}
				return
			}

		} else {

			channel <- Task.TradeResult{
				Error: Task.TaskUnableTrade,
			}
			return
		}

	}()

	return channel

}
