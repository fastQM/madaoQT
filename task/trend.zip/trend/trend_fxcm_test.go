package trend

import (
	"log"
	"testing"
	"time"

	Exchange "madaoQT/exchange"
)

func TestGetFunctions(t *testing.T) {

	// select {
	// case <-time.After(3 * time.Second):
	// 	log.Printf("Timeout")
	// }

	// log.Printf("Balance:%v", fxcm.GetBalance())
	// log.Printf("Ticker:%v", fxcm.GetTicker("EUR/USD"))

	// result := fxcm.Trade(Exchange.TradeConfig{
	// 	Pair:   "EUR/USD",
	// 	Type:   Exchange.TradeTypeBuy,
	// 	Amount: 1,
	// })
	// log.Printf("Result:%v", result)

	// fxcm.GetOpenPositions()

	/*
		2018/05/03 10:04:49 OfferID:1 Pair:EUR/USD
		2018/05/03 10:04:49 OfferID:2 Pair:USD/JPY
		2018/05/03 10:04:49 OfferID:3 Pair:GBP/USD
		2018/05/03 10:04:49 OfferID:4 Pair:USD/CHF
		2018/05/03 10:04:49 OfferID:7 Pair:USD/CAD
		2018/05/03 10:04:49 OfferID:8 Pair:NZD/USD
		2018/05/03 10:04:49 OfferID:10 Pair:EUR/JPY
		2018/05/03 10:04:49 OfferID:11 Pair:GBP/JPY
		2018/05/03 10:04:49 OfferID:16 Pair:AUD/CAD
		2018/05/03 10:04:49 OfferID:17 Pair:AUD/JPY
		2018/05/03 10:04:49 OfferID:19 Pair:NZD/JPY
		2018/05/03 10:04:49 OfferID:22 Pair:GBP/AUD
		2018/05/03 10:04:49 OfferID:28 Pair:AUD/NZD
		2018/05/03 10:04:49 OfferID:1004 Pair:GER30
		2018/05/03 10:04:49 OfferID:1005 Pair:HKG33
		2018/05/03 10:04:49 OfferID:1013 Pair:US30
		2018/05/03 10:04:49 OfferID:2001 Pair:USOil
		2018/05/03 10:04:49 OfferID:4001 Pair:XAU/USD
	*/

	// file := "fxcm_15min"
	// file := "fxcm_2h"
	file := "fxcm_1day"
	var klines []Exchange.KlineValue
	if false {
		fxcm := Exchange.GetFxcmInstance(Exchange.Config{
			Custom: map[string]interface{}{
				"token":   FxcmToken,
				"account": "96080958",
			},
		})
		select {
		case <-time.After(3 * time.Second):
			log.Printf("Timeout")
		}
		klines = fxcm.GetKline("EUR/USD", Exchange.KlinePeriod1Day, 200)
		Exchange.SaveHistory(file, klines)
	} else {
		klines = Exchange.LoadHistory(file)
	}

	// for _, kline := range klines {
	// 	log.Printf("Time:%v", time.Unix(int64(kline.OpenTime), 0))
	// 	log.Printf("High:%.5f Low:%.5f", kline.High, kline.Low)
	// }
	if klines != nil {
		// Exchange.ChangeOffset(0.21)
		Exchange.FXStrategyTrendTest(klines, true, true)
	}
}
