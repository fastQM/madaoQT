package trend

import (
	"log"
	"time"

	Exchange "madaoQT/exchange"
	MongoTrend "madaoQT/mongo/trend"
)

type TradeManager struct {
	Trades MongoTrend.Trades
}

func (p *TradeManager) Init(collection MongoTrend.Trades) {
	p.Trades = collection
}

func (p *TradeManager) OpenPosition(batch string,
	timestamp int64,
	pair string,
	futureType Exchange.TradeType,
	futureOpen float64,
	futureAmount float64) error {

	info := &MongoTrend.TradeInfo{
		Batch:        batch,
		Pair:         pair,
		FutureType:   Exchange.TradeTypeString[futureType],
		FutureOpen:   futureOpen,
		FutureAmount: futureAmount,
		// OpenTime:     time.Unix(timestamp, 0),
		OpenTime: time.Now(),
		Status:   MongoTrend.TradeStatusOpen,
	}

	if err := p.Trades.Insert(info); err != nil {
		Logger.Errorf("Error:%v", err)
		return err
	}

	return nil
}

func (p *TradeManager) ClosePosition(batch string, futureClose float64, result string) error {

	if err := p.Trades.Update(map[string]interface{}{
		"batch": batch,
	}, map[string]interface{}{
		"futureclose": futureClose,
		"closetime":   time.Now(),
		"status":      result,
	}); err != nil {
		Logger.Errorf("Error:%v", err)
		return err
	}

	return nil
}

func (p *TradeManager) GetOpenPositions(pair string) (err error, records []MongoTrend.TradeInfo) {
	if err, records = p.Trades.Find(map[string]interface{}{
		"status": MongoTrend.TradeStatusOpen,
		"pair":   pair,
	}); err != nil {
		return err, nil
	}

	return nil, records
}

func (p *TradeManager) GetClosedPositions() (err error, records []MongoTrend.TradeInfo) {
	if err, records = p.Trades.Find(map[string]interface{}{
		"status": MongoTrend.TradeStatusClose,
	}); err != nil {
		return err, nil
	}

	return nil, records
}

func (p *TradeManager) GetFailedPositions() (err error, records []MongoTrend.TradeInfo) {

	if err, records = p.Trades.Find(map[string]interface{}{
		"status": MongoTrend.TradeStatusError,
	}); err != nil {
		return err, nil
	}
	return nil, records

}

func (p *TradeManager) FixFailedPosition(updates map[string]interface{}) error {

	updates["closetime"] = time.Now()
	updates["status"] = MongoTrend.TradeStatusClose

	if err := p.Trades.Update(map[string]interface{}{
		"batch": updates["batch"],
	}, updates); err != nil {
		Logger.Errorf("Error:%v", err)
		return err
	}

	return nil
}

func (p *TradeManager) CheckDailyProfit(date time.Time) (error, float64) {
	if err, records := p.Trades.GetDailySuccessRecords(date); err != nil {
		return err, 0
	} else {
		return nil, p.CheckProfit(records)
	}
}

func (p *TradeManager) CheckProfit(records []MongoTrend.TradeInfo) float64 {

	var total float64

	for _, record := range records {
		coin := Exchange.ParsePair(record.Pair)[0]
		var futureProfit, fee float64

		amount := constContractRatio[coin] * record.FutureAmount
		if record.FutureOpen == 0 || record.FutureClose == 0 {
			log.Printf("[%v]无效合约数据", record.Batch)
		} else {
			if record.FutureType == Exchange.TradeTypeString[Exchange.TradeTypeOpenLong] {
				futureProfit = (amount/record.FutureClose - amount/record.FutureOpen) * (-1)
			} else {
				futureProfit = (amount/record.FutureOpen - amount/record.FutureClose) * (-1)
			}

			fee += (amount/record.FutureOpen + amount/record.FutureClose) * 0.0005
		}

		log.Printf("[%v][%v]收益:%.8f 手续费:%.8f 净收益:%.8f", record.Batch, record.CloseTime, futureProfit, fee, (futureProfit - fee))
		total += (futureProfit - fee)
	}

	log.Printf("总收益:%.8f", total)
	return total
}
