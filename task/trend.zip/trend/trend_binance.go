package trend

import (
	"encoding/json"
	"errors"
	"log"
	"strings"
	"sync"
	"time"

	Exchange "madaoQT/exchange"
	Mongo "madaoQT/mongo"
	MongoTrend "madaoQT/mongo/trend"
	Task "madaoQT/task"
	Utils "madaoQT/utils"
)

// 1. 只做和大趋势相同的方向，即上升通道不做空，下降通道不做多

// TrendTask 策略适用于在短期内(1-3天)出现大幅波动(10%-30%)的市场
type TrendTaskBinance struct {
	config TrendConfig

	binance Exchange.IExchange

	status       Task.StatusType
	database     *MongoTrend.TrendMongo
	tradeManager *TradeManager
	balance      float64

	klines []Exchange.KlineValue

	positions     map[uint]*TrendPosition
	positionIndex uint

	checkPeriodSec time.Duration

	// 强制平仓
	forceCloseFlag   bool
	forceCloseLength int

	forceAddFlag bool

	errorCounter int
}

var binanceDefaultConfig = TrendConfig{
	Pair:            "eth/usdt",
	Interval:        Exchange.KlinePeriod2Hour,
	OpenLong:        true,
	OpenShort:       true,
	UnitAmount:      200,
	LimitCloseRatio: 0.06,
	LimitOpenRatio:  0.001,
	LossLimit:       0.2,
	FundRatio:       0.9,
}

func (p *TrendTaskBinance) GetDescription() Task.Description {

	return Task.Description{
		Name:  "币安趋势交易",
		Title: "基于币安交易所的趋势策略",
		Desc:  "该策略主要跟踪大幅上涨或者下跌的趋势",
	}
}

func (p *TrendTaskBinance) GetDefaultConfig() interface{} {
	return binanceDefaultConfig
}
func (p *TrendTaskBinance) GetBalances() map[string]interface{} {

	if p.binance != nil {
		return p.binance.GetBalance()
	}

	return nil
}
func (p *TrendTaskBinance) GetTrades() []Mongo.TradesRecord {
	return nil
}
func (p *TrendTaskBinance) GetPositions() []map[string]interface{} {
	var positions []MongoTrend.TradeInfo

	err1, closedPositions := p.tradeManager.GetClosedPositions()
	if err1 != nil {
		Logger.Errorf("GetPositions:Fail to get closed positions %v", err1)
		return nil
	}
	positions = append(positions, closedPositions...)

	err2, openPositions := p.tradeManager.GetOpenPositions(p.config.Pair)
	if err2 != nil {
		Logger.Errorf("GetPositions:Fail to get open positions %v", err2)
		return nil
	}

	positions = append(positions, openPositions...)

	return nil
}
func (p *TrendTaskBinance) GetFailedPositions() []map[string]interface{} {
	return nil
}
func (p *TrendTaskBinance) FixFailedPosition(updateJSON string) error {
	return nil
}
func (p *TrendTaskBinance) Close() {
	return
}
func (p *TrendTaskBinance) GetStatus() Task.StatusType {
	return p.status
}

func (p *TrendTaskBinance) Start(configJSON string) error {

	Logger.Infof("%s", trendTaskExplaination)

	if configJSON == "" {
		p.config = p.GetDefaultConfig().(TrendConfig)
	} else {
		var config TrendConfig
		err := json.Unmarshal([]byte(configJSON), &config)
		if err != nil {
			log.Printf("Fail to get config:%v", err)
			return errors.New(Task.TaskErrorMsg[Task.TaskInvalidConfig])
		}
		p.config = config
	}

	coin := strings.ToUpper(Exchange.ParsePair(p.config.Pair)[0])

	Logger.Info("===========配置(Binance)=====================")
	Logger.Infof("货币:%v", p.config.Pair)
	Logger.Infof("检测周期:%v(分钟)", p.config.Interval)
	Logger.Infof("下单单位:%v(美金)", p.config.UnitAmount)
	Logger.Infof("是否开空:%v, 是否开多:%v", p.config.OpenLong, p.config.OpenShort)
	Logger.Infof("交易记录数据库名：%s", Task.TrendTradeCollectionBinance+"_"+coin)
	Logger.Infof("资金数据库名:%s", Task.TrendBalanceBinance+"_"+coin)
	Logger.Info("==========================================")

	err, key := getExchangeKey(Exchange.NameBinance)
	if err != nil {
		return err
	}

	p.status = Task.StatusProcessing
	p.checkPeriodSec = CheckingPeriodMS

	p.database = &MongoTrend.TrendMongo{
		TradeCollectionName:   Task.TrendTradeCollectionBinance + "_" + coin,
		BalanceCollectionName: Task.TrendBalanceBinance + "_" + coin,
		Server:                MongoServer,
		// Sock5Proxy:            "SOCKS5:127.0.0.1:1080",
	}
	if err := p.database.Connect(); err != nil {
		Logger.Errorf("Error:%v", err)
		return err
	}

	p.tradeManager = new(TradeManager)
	p.tradeManager.Init(p.database.TradeCollection)
	p.positions = make(map[uint]*TrendPosition)
	p.loadPosition()

	p.binance = new(Exchange.Binance)
	p.binance.SetConfigure(Exchange.Config{
		API:    key.API,
		Secret: key.Secret,
		// Proxy:  "SOCKS5:127.0.0.1:1080",
	})

	go func() {
		for {
			select {

			case <-time.After(p.checkPeriodSec * time.Millisecond):
				if p.status == Task.StatusError || p.status == Task.StatusNone {
					Logger.Debug("状态异常或退出")
					return
				}

				p.database.Refresh()
				p.Watch()
			}
		}
	}()

	return nil
}

func (p *TrendTaskBinance) loadPosition() {
	var records []MongoTrend.TradeInfo
	var err error

	if err, records = p.tradeManager.GetOpenPositions(p.config.Pair); err != nil {
		Logger.Errorf("Fail to load positions:%v", err)
		return
	}

	if records != nil && len(records) > 0 {
		for _, record := range records {
			var position TrendPosition
			var config Exchange.TradeConfig
			config.Batch = record.Batch
			config.Amount = record.FutureAmount
			config.Limit = p.config.LimitOpenRatio
			config.Pair = record.Pair
			config.Type = Exchange.TradeTypeInt(record.FutureType)
			config.Price = record.FutureOpen
			position.TimeStamp = record.OpenTime.Unix()
			position.Amount = config.Amount
			position.config = config
			p.positions[p.positionIndex] = &position
			p.positionIndex++
			Logger.Infof("Position:%v", position)
		}
	}
}

func (p *TrendTaskBinance) checkFunds(lastPrice float64) float64 {

	coin := Exchange.ParsePair(p.config.Pair)[0]

	var usedAmount float64
	for _, position := range p.positions {
		usedAmount += position.Amount * lastPrice
	}

	if usedAmount == 0 && p.balance == 0 {
		balances := p.GetBalances()
		if balances != nil {
			coinBalance := balances[strings.ToUpper(coin)].(float64)
			usdt := balances["USDT"].(float64)

			var balanceData MongoTrend.BalanceInfo
			balanceData.Item = make([]MongoTrend.BalanceItemInfo, 2)
			balanceData.Item[0] = MongoTrend.BalanceItemInfo{
				Coin:    strings.ToUpper(coin),
				Balance: coinBalance,
			}
			balanceData.Item[1] = MongoTrend.BalanceItemInfo{
				Coin:    "USDT",
				Balance: usdt,
			}
			if err := p.database.BalanceCollection.Insert(balanceData); err != nil {
				Logger.Errorf("Invalid to save data:%v", err)
			}

			amount := coinBalance * lastPrice
			if amount > usdt {
				amount = usdt
			}

			p.balance = amount * p.config.FundRatio
		}
	}

	Logger.Infof("开仓单位：%v 已开仓：%.2f 开仓总量:%.2f", p.config.UnitAmount, usedAmount, p.balance)
	if (usedAmount + p.config.UnitAmount) > p.balance {
		// 币安最小交易额度是10美金
		if p.balance-usedAmount > 100 {
			return p.balance - usedAmount
		}

		return 0
	}
	return p.config.UnitAmount

}

func (p *TrendTaskBinance) Watch() {

	if p.klines == nil || len(p.klines) == 0 {
		p.klines = p.binance.GetKline(p.config.Pair, p.config.Interval, 200)
		if p.klines == nil {
			Logger.Errorf("未获取均线信息")
			return
		}
		return

	} else {
		current := p.klines[len(p.klines)-1]

		if time.Now().Unix()-int64(current.OpenTime) > int64(p.config.Interval*60) {
			p.klines = nil
			Logger.Info("更新均线")
			p.forceCloseFlag = false
			return

		} else {
			err2, _, askFuturePlacePrice, _, bidFuturePlacePrice := Task.CalcDepthPrice(false, nil, p.binance, p.config.Pair, p.config.UnitAmount)
			if err2 != nil {
				Logger.Debugf("深度无效:%s", err2.Error())
				return
			}

			Logger.Infof("当前深度价格:%.2f %.2f", askFuturePlacePrice, bidFuturePlacePrice)
			// 挂的买单高于现有当前最高价才算最高价
			if bidFuturePlacePrice > current.High {
				p.klines[len(p.klines)-1].High = bidFuturePlacePrice
			}

			if askFuturePlacePrice < current.Low {
				p.klines[len(p.klines)-1].Low = askFuturePlacePrice
			}

			length := len(p.klines)
			array5 := p.klines[length-5 : length]
			array20 := p.klines[length-20 : length]

			avg5 := Exchange.GetAverage(5, array5)
			avg20 := Exchange.GetAverage(20, array20)

			if avg5 > avg20 {
				Logger.Infof("做多使用买入(卖方)价格作为收盘价")
				p.klines[len(p.klines)-1].Close = askFuturePlacePrice
			} else if avg20 > avg5 {
				Logger.Infof("卖空使用卖出价格作为收盘价")
				p.klines[len(p.klines)-1].Close = bidFuturePlacePrice
			} else {
				p.klines[len(p.klines)-1].Close = (askFuturePlacePrice + bidFuturePlacePrice) / 2
			}
		}
	}

	kline := p.klines
	if kline == nil || len(kline) < 20 {
		Logger.Errorf("无效K线数据")
		return
	}

	length := len(kline)
	current := kline[length-1]

	Logger.Infof("[High]%.2f [Open]%.2f [Close]%.2f [Low]%.2f [Volumn]%.2f", current.High, current.Open, current.Close, current.Low, current.Volumn)
	// Logger.Infof("服务器时间:%d[%s] 当前时间:%d[%s]",
	// 	int(current.OpenTime), time.Unix(int64(current.OpenTime), 0).Format(Global.TimeFormat),
	// 	time.Now().Unix(), time.Now().Format(Global.TimeFormat))

	// var timeFlag bool
	// if time.Now().Unix()-int64(current.OpenTime) > 240 {
	// 	timeFlag = true
	// }

	// 是否需要减仓
	if p.CheckAreaClosePosition(kline) {
		p.adjustDuration(true)
		return
	}

	// 资金管理
	amount := p.checkFunds(current.Close)
	if amount == 0 {
		Logger.Info("无可用仓位...不开仓")
		p.adjustDuration(false)
		return
	}

	if true {

		if p.checkBreakPosition(kline, amount) {
			p.adjustDuration(true)
		}
	}
}

func (p *TrendTaskBinance) checkBreakPosition(kline []Exchange.KlineValue, amount float64) bool {
	err, high, low := p.getLastPeriodArea(kline)
	if err != nil {
		Logger.Errorf("Error in getLastPeriodArea():%s", err.Error())
		return false
	}

	length := len(kline)
	current := kline[length-1]

	array5 := kline[length-5 : length]
	array10 := kline[length-10 : length]

	avg5 := Exchange.GetAverage(5, array5)
	avg10 := Exchange.GetAverage(10, array10)

	Logger.Infof("前一个周期波动区间 High: %.2f Low: %.2f Avg5: %.2f Avg10: %.2f", high, low, avg5, avg10)

	if p.forceCloseFlag == true {
		Logger.Debug("减仓当前周期不加仓")
		return false
	}

	// 有可能假突破
	if (current.Close > high) && (avg5 > avg10) && p.config.OpenLong {

		err2, _, askFuturePlacePrice, _, _ := Task.CalcDepthPrice(false, nil, p.binance, p.config.Pair, p.config.UnitAmount)
		if err2 != nil {
			Logger.Debugf("深度无效: %s", err2.Error())
			return false
		}

		Logger.Infof("突破前期高点,做多价格:%.2f", askFuturePlacePrice)
		batch := Utils.GetRandomHexString(12)
		timestamp := int64(current.OpenTime)
		p.openPosition(timestamp, Exchange.TradeConfig{
			Batch:  batch,
			Pair:   p.config.Pair,
			Type:   Exchange.TradeTypeBuy,
			Price:  askFuturePlacePrice,
			Amount: amount / askFuturePlacePrice,
			Limit:  p.config.LimitOpenRatio,
		})
		return true

	} else if (current.Close < low) && (avg5 < avg10) && p.config.OpenShort {
		err2, _, _, _, bidFuturePlacePrice := Task.CalcDepthPrice(false, nil, p.binance, p.config.Pair, p.config.UnitAmount)
		if err2 != nil {
			Logger.Infof("深度无效")
			return false
		}

		Logger.Infof("突破前期低点加仓，做空价格:%.2f", bidFuturePlacePrice)

		batch := Utils.GetRandomHexString(12)
		timestamp := int64(current.OpenTime)
		p.openPosition(timestamp, Exchange.TradeConfig{
			Batch:  batch,
			Pair:   p.config.Pair,
			Type:   Exchange.TradeTypeSell,
			Price:  bidFuturePlacePrice,
			Amount: amount / bidFuturePlacePrice,
			Limit:  p.config.LimitOpenRatio,
		})
		return true
	}

	return false
}

func (p *TrendTaskBinance) adjustDuration(hasTrade bool) {

	if hasTrade {
		if p.checkPeriodSec == CheckingPeriodMS {
			Logger.Debugf("检测周期变成%d毫秒", TradingPeriodMS)
			p.checkPeriodSec = TradingPeriodMS
		}
	} else {
		if p.checkPeriodSec == TradingPeriodMS {
			// 5 minutes without trading
			Logger.Debugf("检测周期变成%d毫秒", CheckingPeriodMS)
			p.checkPeriodSec = CheckingPeriodMS
		}
	}
}

func (p *TrendTaskBinance) openPosition(timestamp int64, tradeConfig Exchange.TradeConfig) {

	tradeChannel := Task.ProcessTradeRoutineIOC(p.binance, tradeConfig, nil)

	var waitGroup sync.WaitGroup
	var tradeResult Task.TradeResult

	waitGroup.Add(1)
	go func() {
		select {
		case tradeResult = <-tradeChannel:
			Logger.Debugf("交易结果:%v", tradeResult)
			waitGroup.Done()
		}
	}()

	waitGroup.Wait()

	if tradeResult.Error != Task.TaskIOCReturn {
		if err := p.tradeManager.OpenPosition(tradeConfig.Batch,
			timestamp,
			tradeConfig.Pair,
			tradeConfig.Type,
			tradeResult.AvgPrice,
			tradeResult.DealAmount); err != nil {
			Logger.Error("Fail to save fund info")
		}
	}

	if tradeResult.Error == Task.TaskErrorSuccess {
		var position TrendPosition
		var config Exchange.TradeConfig
		config.Batch = tradeConfig.Batch
		config.Amount = tradeResult.DealAmount
		config.Limit = tradeConfig.Limit
		config.Pair = tradeConfig.Pair
		config.Type = tradeConfig.Type
		config.Price = tradeResult.AvgPrice
		position.TimeStamp = timestamp
		position.Amount = config.Amount
		position.config = config
		p.positions[p.positionIndex] = &position
		p.positionIndex++
	} else if tradeResult.Error != Task.TaskIOCReturn {
		// 开仓失败，手工检查
		p.tradeManager.ClosePosition(tradeConfig.Batch, 0, MongoTrend.TradeStatusError)
		p.errorCounter++
		Logger.Errorf("Trade Error:%v", tradeResult.Error)
		if p.errorCounter > 100 {
			p.status = Task.StatusError
		}
	}

}

func (p *TrendTaskBinance) CheckAreaClosePosition(values []Exchange.KlineValue) bool {

	if p.positions == nil || len(p.positions) == 0 {
		return false
	}

	length := len(values)
	current := values[length-1]
	closePrice := current.Close

	for index, position := range p.positions {
		var limitClosePrice float64
		var placeClosePrice float64
		var openLongFlag bool
		var closeFlag bool
		config := position.config
		Logger.Debugf("仓位配置:%v", config)

		if config.Type == Exchange.TradeTypeBuy || config.Type == Exchange.TradeTypeOpenLong {

			if closePrice < config.Price*(1-p.config.LossLimit) {
				Logger.Errorf("市场价格异常，请手动操作")
				p.errorCounter++
				return false
			}

			limitClosePrice = config.Price * (1 - p.config.LimitCloseRatio)
			openLongFlag = true
		} else if config.Type == Exchange.TradeTypeSell || config.Type == Exchange.TradeTypeOpenShort {

			if closePrice > config.Price*(1+p.config.LossLimit) {
				Logger.Errorf("市场价格异常，请手动操作")
				p.errorCounter++
				return false
			}

			limitClosePrice = config.Price * (1 + p.config.LimitCloseRatio)
			openLongFlag = false
		} else {
			Logger.Errorf("无效的交易类型")
			continue
		}

		err2, _, askSpotPlacePrice, _, bidSpotPlacePrice := Task.CalcDepthPrice(false, nil, p.binance, p.config.Pair, p.config.UnitAmount)
		if err2 != nil {
			return false
		}

		high, low, err := Exchange.GetCurrentPeriodArea(values)
		if err != nil {
			Logger.Errorf("Fail to get current area:%s", err.Error())
			return false
		}

		offset := 0.382

		// if (high-low)*100/low < 3 {
		// 	logger.Infof("波动太小不操作")
		// 	return false, 0
		// }

		array5 := values[length-5 : length]
		array10 := values[length-10 : length]

		avg5 := Exchange.GetAverage(5, array5)
		avg10 := Exchange.GetAverage(10, array10)

		// log.Printf("Avg5:%.2f Avg10:%.2f Avg20:%.2f", avg5, avg10, avg20)

		if openLongFlag {
			if closePrice < limitClosePrice {
				Logger.Debugf("做多止损,止损价格:%.2f", limitClosePrice)
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
		} else {
			if closePrice > limitClosePrice {
				Logger.Debugf("做空止损,止损价格:%.2f", limitClosePrice)
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
		}

		if int64(current.OpenTime) == position.TimeStamp {
			Logger.Info("忽略开仓期间的价格波动")
			return false
		}

		if openLongFlag {

			Logger.Debugf("当前波动区间 高:%.2f 低:%.2f 做多平仓点:%.2f", high, low, (high - (high-low)*offset))

			if p.forceCloseFlag && p.forceCloseLength > 0 {

				p.forceCloseLength--

				Logger.Debugf("手工强制平仓")
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if (high-low)*100/low > 3 && (closePrice < (high - (high-low)*offset)) {
				// Logger.Debugf("当前波动区间 高:%.2f 低:%.2f 做多平仓点:%.2f", high, low, (high - (high-low)*offset))
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if avg5 > avg10 {

			} else {
				Logger.Debugf("做多趋势破坏平仓")
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
		} else {

			Logger.Debugf("当前波动区间 高:%.2f 低:%.2f 做空平仓点:%.2f", high, low, (low + (high-low)*offset))

			if p.forceCloseFlag && p.forceCloseLength > 0 {

				p.forceCloseLength--

				Logger.Debugf("手工强制平仓")
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if (high-low)*100/low > 3 && (closePrice > (low + (high-low)*offset)) {
				// Logger.Debugf("当前波动区间 高:%.2f 低:%.2f 做空平仓点:%.2f", high, low, (low + (high-low)*offset))
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if avg5 < avg10 {

			} else {
				Logger.Debugf("做空趋势破坏平仓")
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
		}
	__DONE:
		if closeFlag {

			config := position.config
			config.Price = placeClosePrice
			config.Type = Exchange.RevertTradeType(config.Type)
			channelFuture := Task.ProcessTradeRoutineIOC(p.binance, config, nil)

			var waitGroup sync.WaitGroup
			var futureResult Task.TradeResult

			waitGroup.Add(1)
			go func() {
				select {
				case futureResult = <-channelFuture:
					Logger.Debugf("交易结果:%v", futureResult)
					waitGroup.Done()
				}
			}()

			waitGroup.Wait()

			if futureResult.Error == Task.TaskErrorSuccess {
				Logger.Infof("平仓成功")
				delete(p.positions, index)
				p.tradeManager.ClosePosition(config.Batch, futureResult.AvgPrice, MongoTrend.TradeStatusClose)

				if len(p.positions) == 0 {
					Logger.Infof("全部平仓,无仓位")
					p.adjustDuration(false)
					p.balance = 0
					// 只在下一个周期设置为false
					p.forceCloseFlag = true
					p.forceAddFlag = false
					return false
				}
			} else {
				Logger.Infof("平仓失败")
				delete(p.positions, index)
				p.tradeManager.ClosePosition(config.Batch, futureResult.AvgPrice, MongoTrend.TradeStatusError)
				p.errorCounter++
				Logger.Errorf("Trade Error:%v", futureResult.Error)
				if p.errorCounter > 100 {
					p.status = Task.StatusError
				}
			}

			return true
		}

		return false
	}

	return false
}

// 如果需要平仓，则返回true，后续不再开仓；否则返回false，后续可能开仓
func (p *TrendTaskBinance) CheckClosePosition(values []Exchange.KlineValue, currentKlineStart int) bool {

	if p.positions == nil || len(p.positions) == 0 {
		return false
	}

	length := len(values)
	current := values[length-1]
	highPrice := current.High
	lowPrice := current.Low
	closePrice := current.Close

	for index, position := range p.positions {
		var lossLimitPrice, placeClosePrice float64
		var openLongFlag bool
		var closeFlag bool
		config := position.config
		Logger.Debugf("仓位配置:%v", config)

		if int64(current.OpenTime) == position.TimeStamp {
			Logger.Info("忽略开仓期间的价格波动")
			return false
		}

		if config.Type == Exchange.TradeTypeBuy || config.Type == Exchange.TradeTypeOpenLong {

			if closePrice < config.Price*(1-p.config.LossLimit) {
				Logger.Errorf("市场价格异常，请手动操作")
				p.errorCounter++
				return false
			}

			lossLimitPrice = config.Price * (1 - p.config.LimitCloseRatio)
			// targetProfitPrice = openPrice * (1 + profitLimit)
			openLongFlag = true
		} else if config.Type == Exchange.TradeTypeSell || config.Type == Exchange.TradeTypeOpenShort {

			if closePrice > config.Price*(1+p.config.LossLimit) {
				Logger.Errorf("市场价格异常，请手动操作")
				p.errorCounter++
				return false
			}

			lossLimitPrice = config.Price * (1 + p.config.LimitCloseRatio)
			// targetProfitPrice = openPrice * (1 - lossLimit)
			openLongFlag = false
		} else {
			Logger.Errorf("无效的交易类型")
			continue
		}

		err2, _, askSpotPlacePrice, _, bidSpotPlacePrice := Task.CalcDepthPrice(false, nil, p.binance, p.config.Pair, p.config.UnitAmount)
		if err2 != nil {
			return false
		}

		var timeFlag bool
		if time.Now().Unix()-int64(currentKlineStart) > int64(p.config.Interval*60*4/5) {
			timeFlag = true
		}

		if openLongFlag {
			// 还要考虑瞬时价格突变的保护措施
			if lowPrice < lossLimitPrice {
				Logger.Debugf("做多止损,止损价格:%v", lossLimitPrice)
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
			}
		} else {
			if highPrice > lossLimitPrice {
				Logger.Debugf("做空止损,止损价格:%v", lossLimitPrice)
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
			}
		}

		array5 := values[length-5 : length]
		array10 := values[length-10 : length]

		avg5 := Exchange.GetAverage(5, array5)
		avg10 := Exchange.GetAverage(10, array10)

		// Logger.Debugf("[Avg5]%.2f [Avg10]%.2f [Avg20]%.2f", avg5, avg10, avg20)

		if openLongFlag {
			if p.forceCloseFlag {
				Logger.Debugf("手工强制平仓")
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
			if avg5 > avg10 {

			} else {
				Logger.Debugf("做多趋势破坏平仓")
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if closePrice < avg10 {
				Logger.Debugf("突破十日线平仓")
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			// if closePrice < avg10 {
			// 价格柱三分之一突破十日均线平仓
			if (closePrice < avg5) && (highPrice-avg5) < (avg5-lowPrice) && timeFlag {
				Logger.Debugf("突破五日线平仓")
				placeClosePrice = bidSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
		} else {

			if p.forceCloseFlag {
				Logger.Debugf("手工强制平仓")
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if avg5 < avg10 {

			} else {
				log.Printf("做空趋势破坏平仓")
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			if closePrice > avg10 {
				Logger.Debugf("突破十日线平仓")
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}

			// if closePrice > avg10 {
			// 当前价格高于十日均线并且突出长度大于当天价格柱的1/3
			if (closePrice > avg5) && (highPrice-avg5) > (avg5-lowPrice) && timeFlag {
				log.Printf("突破五日线平仓")
				placeClosePrice = askSpotPlacePrice
				closeFlag = true
				goto __DONE
			}
		}
	__DONE:
		if closeFlag {

			config := position.config
			config.Price = placeClosePrice
			config.Type = Exchange.RevertTradeType(config.Type)
			tradeChannel := Task.ProcessTradeRoutineIOC(p.binance, config, nil)

			var waitGroup sync.WaitGroup
			var tradeResult Task.TradeResult

			waitGroup.Add(1)
			go func() {
				select {
				case tradeResult = <-tradeChannel:
					Logger.Debugf("交易结果:%v", tradeResult)
					waitGroup.Done()
				}
			}()

			waitGroup.Wait()

			if tradeResult.Error == Task.TaskErrorSuccess {
				Logger.Infof("平仓成功")
				delete(p.positions, index)
				p.tradeManager.ClosePosition(config.Batch, tradeResult.AvgPrice, MongoTrend.TradeStatusClose)

				if len(p.positions) == 0 {
					Logger.Infof("全部平仓,无仓位")
					p.adjustDuration(false)
					p.balance = 0
					p.forceCloseFlag = false
					return false
				}
			} else if tradeResult.Error != Task.TaskIOCReturn {
				Logger.Debug("IOC平仓失败")
			} else {
				Logger.Error("平仓失败")
				delete(p.positions, index)
				p.tradeManager.ClosePosition(config.Batch, tradeResult.AvgPrice, MongoTrend.TradeStatusError)
				p.errorCounter++
				Logger.Errorf("Trade Error:%v", tradeResult.Error)
				if p.errorCounter > 100 {
					p.status = Task.StatusError
				}
			}

			return true
		}

		return false
	}

	return false
}

func (p *TrendTaskBinance) getLastPeriodArea(kline []Exchange.KlineValue) (err error, high float64, low float64) {

	var start int
	found := false

	length := len(kline)
	array10 := kline[length-10 : length]
	array20 := kline[length-20 : length]

	avg10 := Exchange.GetAverage(10, array10)
	avg20 := Exchange.GetAverage(20, array20)

	var isOpenLong bool
	if avg10 > avg20 {
		isOpenLong = true
	} else {
		isOpenLong = false
	}

	if isOpenLong {

		step := 0
		for i := len(kline) - 1; i >= 0; i-- {

			if i-20 < 0 {
				start = i
				found = true
				break
			}

			array10 := kline[i-10 : i]
			array20 := kline[i-20 : i]

			avg10 := Exchange.GetAverage(10, array10)
			avg20 := Exchange.GetAverage(20, array20)

			if step == 0 {
				if avg10 < avg20 {
					step = 1
					continue
				}
			} else if step == 1 {
				if avg10 > avg20 {
					step = 2
					continue
				}
			} else if step == 2 {
				if avg10 < avg20 {
					start = i
					found = true
					break
				}
			}
		}

	} else {
		step := 0
		for i := len(kline) - 1; i >= 0; i-- {

			if i-20 < 0 {
				start = i
				found = true
				break
			}

			array10 := kline[i-10 : i]
			array20 := kline[i-20 : i]

			avg10 := Exchange.GetAverage(10, array10)
			avg20 := Exchange.GetAverage(20, array20)

			if step == 0 {
				if avg10 > avg20 {
					step = 1
					continue
				}
			} else if step == 1 {
				if avg10 < avg20 {
					step = 2
					continue
				}
			} else if step == 2 {
				if avg10 > avg20 {
					start = i
					found = true
					break
				}
			}
		}
	}

	if found {
		high = 0
		low = 0
		// Logger.Infof("区间起点:%v", time.Unix(int64(kline[start].OpenTime), 0))
		for i := start; i < len(kline)-1; i++ {
			tmp := (kline[i].High*0.2 + kline[i].Close*0.8)
			if high == 0 {
				high = tmp
			} else if high < tmp {
				high = tmp
			}

			tmp = (kline[i].Low*0.2 + kline[i].Close*0.8)
			if low == 0 {
				low = tmp
			} else if low > tmp {
				low = tmp
			}
		}

		return nil, high, low

	}

	return errors.New("Perios is not Found"), 0, 0

}

func (p *TrendTaskBinance) ForceClosePositions(ratio int) {

	Logger.Errorf("强制平仓")

	if p.positions == nil || len(p.positions) == 0 {
		return
	}

	p.forceCloseLength = len(p.positions) / ratio
	p.forceCloseFlag = true
}
