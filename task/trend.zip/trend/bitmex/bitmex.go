package main

import (
	"encoding/json"
	"fmt"
	"log"
	"madaoQT/exchange"
	"madaoQT/task/trend"
)

// Bitmex 系统总是负载，所以不考虑使用
func main() {

	trendTask := new(trend.TrendBitmex)

	config := trend.TrendConfig{
		Pair:            "btc/usdt",
		Interval:        exchange.KlinePeriod1Hour,
		UnitAmount:      100,
		LimitCloseRatio: 0.06,
		LimitOpenRatio:  0.001,
		LossLimit:       0.2,
		FundRatio:       0.1,
		OpenLong:        true,
		OpenShort:       false,
	}

	jsonConfig, err := json.Marshal(config)
	if err != nil {
		log.Printf("Error:%v", err)
		return
	}

	err = trendTask.Start(string(jsonConfig))
	if err != nil {
		log.Printf("Error:%v", err)
		return
	}

	go func() {
		var cmd string
		for {
			fmt.Scanln(&cmd)

			switch cmd {
			case "c3":
				trendTask.ForceClosePositions(3)
				cmd = ""
			case "c2":
				trendTask.ForceClosePositions(2)
				cmd = ""
			case "ca":
				trendTask.ForceClosePositions(1)
				cmd = ""
			case "a":
				trendTask.ForceAddPositions()
				cmd = ""
			default:
				log.Printf("==========Command==========")
				log.Printf("C3: 强制平仓1/3仓位")
				log.Printf("C2: 强制平仓1/2仓位")
				log.Printf("CA: 强制全平")
				log.Printf("A: 增加仓位")
				log.Printf("===========================")
				cmd = ""
			}
		}
	}()
	select {}
}
