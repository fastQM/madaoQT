package bitmex

func main() {

}
