package main

import (
	"log"
	"madaoQT/exchange"
	Mongo "madaoQT/mongo"
)

func main() {
	mongo := &Mongo.ExchangeDB{
		Server:     "mongodb://34.218.78.117:28017",
		Sock5Proxy: "SOCKS5:127.0.0.1:1080",
	}
	exchange.AddExchangeKey(mongo, exchange.NameBitmex, "", "")

	err, keys := exchange.GetExchangeKey(mongo, exchange.NameBitmex, nil, nil)
	if err != nil {
		log.Printf("Error:%v", err)
		return
	}

	log.Printf("api:%s, secret:%s", keys.API, keys.Secret)
}
