package trend

import (
	"log"
	MongoTrend "madaoQT/mongo/trend"
	Task "madaoQT/task"
	"testing"
	"time"
)

func TestCheckResult(t *testing.T) {

	db := &MongoTrend.TrendMongo{
		BalanceCollectionName: Task.TrendBalanceBinance,
		Server:                MongoServer,
		Sock5Proxy:            "SOCKS5:127.0.0.1:1080",
	}
	if err := db.Connect(); err != nil {
		Logger.Errorf("Error3:%v", err)
		return
	}

	balanceManager := new(BalanceManager)
	balanceManager.Init(&db.BalanceCollection)

	// err := balanceManager.SetBalanceStart("5ac3394f4b1596f2dbbabcff")
	// if err != nil {
	// 	log.Printf("Err:%v", err)
	// 	return
	// }

	err, balances := balanceManager.GetListFromLastStart()
	if err != nil {
		log.Printf("Error:%v", err)
		return
	}

	for _, balance := range balances {
		log.Printf("Result:%v %v", balance.Time.Unix(), balance)
	}

	// start := balances[0].Item

	// balanceMap := make(map[string][]float64)

	// for i, item := range start {
	// 	balanceMap[item.Coin] = make([]float64, len(balances))
	// 	for j, balance := range balances {
	// 		balanceMap[item.Coin][j] = balance.Item[i].Balance
	// 	}
	// }

	// for key, value := range balanceMap {
	// 	Logger.Printf("Coin:%s", key)
	// 	for i := 1; i < len(value); i++ {
	// 		log.Printf("初始资金:%.2f%% 上一轮:%.2f%%", (value[i]-value[0])*100/value[0], (value[i]-value[i-1])*100/value[i-1])
	// 	}
	// 	log.Printf("单位净值:%.2f", 1*(1+(value[len(value)-1]-value[0])/value[0]))
	// }

	var profitCounter, lossCounter int
	for _, item := range balances[0].Item {
		Logger.Printf("Coin:%s", item.Coin)
		for j := 1; j < len(balances); j++ {
			for _, coin := range balances[j].Item {
				log.Printf("当前时间:%v", balances[j].Time)
				if coin.Coin == item.Coin {
					// log.Printf("初始资金:%.2f", (coin.Balance-item.Balance)*100/item.Balance)
					log.Printf("当前单位净值:%f", 1+(coin.Balance-item.Balance)/item.Balance)

				}
				for _, previous := range balances[j-1].Item {
					if coin.Coin == previous.Coin {
						log.Printf("上一轮:%.2f%%", (coin.Balance-previous.Balance)*100/previous.Balance)
						if coin.Balance > previous.Balance {
							profitCounter++
						} else if coin.Balance < previous.Balance {
							lossCounter++
						}
					}
				}
			}

		}
	}
	log.Printf("盈利次数:%d 亏损次数:%d", profitCounter, lossCounter)

	date := time.Date(2018, 4, 1, 0, 0, 0, 0, time.Local)
	today := time.Now()

	for {
		log.Printf("Date:%v", date.Format("2006-01-02"))
		_, last := balanceManager.GetDialyLast(date)
		log.Printf("Last:%v", last)
		if date.AddDate(0, 0, 1).After(today) {
			break
		} else {
			date = date.AddDate(0, 0, 1)
		}
	}

}
