package main

import (
	Exchange "madaoQT/exchange"
	Task "madaoQT/task/trend"
	"syscall"
)

var TestCTPConfig = map[string]interface{}{
	"marketaddr": "tcp://180.168.212.228:41213",
	"tradeaddr":  "tcp://180.168.212.228:41205",
	"broker":     "8080",
	"investor":   "20082100",
	"password":   "25250300",
	"instruments": []map[string]interface{}{
		{"name": "v1809"},
		// {"name": "CF901"},
		// {"name": "AP810"},
		// {"name": "AP901"},
	},
}

func main() {

	dll := &Exchange.CTPDll{
		Dll: syscall.NewLazyDLL("CTPDll2.dll"),
	}

	trendTask := &Task.TrendCTP{
		Ctpdll: dll,
	}

	trendTask.Start("")

	select {}
}

// test
// func main() {

// 	dll := &Exchange.CTPDll{
// 		Dll: syscall.NewLazyDLL("CTPDll2.dll"),
// 	}

// 	if configS, err := json.Marshal(TestCTPConfig); err != nil {
// 		log.Printf("Error:%v", err)
// 		return
// 	} else {
// 		if !dll.SetConfig(string(configS)) {
// 			log.Printf("Fail to config CTP")
// 			return
// 		}
// 	}

// 	go func() {
// 		log.Printf("启动监视线程")
// 		dll.InitMarket()
// 	}()

// 	go func() {
// 		log.Printf("启动交易线程")
// 		dll.InitTrade()
// 	}()

// 	Utils.SleepAsyncBySecond(3)
// 	result := dll.GetInstrumentInfo("MA809")
// 	log.Printf("result:%v", result)

// 	// result = dll.MarketOpenPosition("MA809", 1, 1)
// 	// log.Printf("result:%v", result)

// 	result = dll.MarketClosePosition("MA809", 1, 1)
// 	log.Printf("result:%v", result)

// 	Utils.SleepAsyncBySecond(1)
// 	result = dll.GetPositionInfo("MA809")
// 	log.Printf("result:%v", result)
// }

// [EXCH][INFO] 2018-05-29 21:22:14 GetInstrumentInfo:map[DeliveryYear:2018 DeliveryMonth:9 VolumeMultiple:10 LongMarginRatio:0.06999999999999999 ShortMarginRatio:0.06999999999999999 InstrumentID:MA809]
// 2018/05/29 21:22:14 result:map[DeliveryMonth:9 VolumeMultiple:10 LongMarginRatio:0.06999999999999999 ShortMarginRatio:0.06999999999999999 InstrumentID:MA809 DeliveryYear:2018]
// 开仓请求:MA809 开仓数量:1 买入:1--->>> 市价开仓录入请求: 0, 成功
// --->>> OnRtnOrder
// --->>> OnRtnOrder
// --->>> OnRtnOrder
// --->>> OnRtnOrder
// --->>> OnRtnTrade
// [EXCH][INFO] 2018-05-29 21:22:15 MarketOpenPosition:map[TradeID:2018053000470924 TradeDate:20180530 TradeTime:21:22:16 Price:2755 Volume:1 TradeType:48 status:success]
// 2018/05/29 21:22:15 result:map[TradeDate:20180530 TradeTime:21:22:16 Price:2755 Volume:1 TradeType:48 status:success TradeID:2018053000470924]
// --->>> 请求查询投资者持仓: 0, 成功
// --->>> OnRspQryInvestorPosition
// [EXCH][INFO] 2018-05-29 21:22:16 GetPositionInfo:map[HedgeFlag:49 PositionDate:49 LongFrozenAmount:0 PositionCost:27550 Commission:2.5 PositionProfit:-10 OpenCost:27550 InstrumentID:MA809 Position:1 CloseVolume:0 OpenAmount:27550 ExchangeMargin:1928.5 MarginRateByMoney:0.13 PosiDirection:50 ShortFrozen:0 CloseAmount:0 CloseProfit:0 MarginRateByVolume:0 LongFrozen:0 ShortFrozenAmount:0 OpenVolume:1 TodayPosition:1]
// 2018/05/29 21:22:16 result:map[CloseAmount:0 CloseProfit:0 MarginRateByVolume:0 PosiDirection:50 ShortFrozen:0 OpenVolume:1 TodayPosition:1 LongFrozen:0 ShortFrozenAmount:0 LongFrozenAmount:0 PositionCost:27550 Commission:2.5 PositionProfit:-10 OpenCost:27550 HedgeFlag:49 PositionDate:49 CloseVolume:0 OpenAmount:27550 ExchangeMargin:1928.5 MarginRateByMoney:0.13 InstrumentID:MA809 Position:1]
