package trend

import (
	"encoding/json"
	"log"
	"syscall"
	"testing"

	Exchange "madaoQT/exchange"
	Utils "madaoQT/utils"
)

var TestCTPConfig = map[string]interface{}{
	"marketaddr": "tcp://180.168.212.228:41213",
	"tradeaddr":  "tcp://180.168.212.228:41205",
	"broker":     "8080",
	"investor":   "20082100",
	"password":   "25250300",
	"instruments": []map[string]interface{}{
		{"name": "MA809"},
		// {"name": "CF901"},
		// {"name": "AP810"},
		// {"name": "AP901"},
	},
}

func TestTrade(t *testing.T) {

	dll := &Exchange.CTPDll{
		Dll: syscall.NewLazyDLL("CTPDll2.dll"),
	}

	if configS, err := json.Marshal(TestCTPConfig); err != nil {
		log.Printf("Error:%v", err)
		return
	} else {
		if !dll.SetConfig(string(configS)) {
			log.Printf("Fail to config CTP")
			return
		}
	}

	go func() {
		Logger.Infof("启动价格监视线程")
		dll.InitMarket()
	}()

	go func() {
		Logger.Infof("启动交易线程")
		dll.InitTrade()
	}()

	Utils.SleepAsyncBySecond(3)

	result := dll.MarketOpenPosition("MA809", 1, 1)
	log.Printf("result:%v", result)

	Utils.SleepAsyncBySecond(1)
	result = dll.GetPositionInfo("MA809")
	log.Printf("result:%v", result)
}
