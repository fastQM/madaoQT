package trend

import (
	"errors"
	MongoTrend "madaoQT/mongo/trend"
	"time"

	"gopkg.in/mgo.v2/bson"
)

type FundConfig struct {
	// 启动资金占比
	StartRatio float64
	// 最大资金占比
	MaxRatio float64
	// 单次资金涨幅超过该比例重置资金比例
	ResetRatio float64
	// 资金回撤比例触发
	Step float64
	// 资金回撤比例触发资金占比升幅
	Raise float64
}

var defaultFundConfig = FundConfig{

	StartRatio: 0.1,
	MaxRatio:   0.2,
	ResetRatio: 0.1,
	Step:       0.03,
	Raise:      0.01,
}

type BalanceManager struct {
	balanceCollection *MongoTrend.BalanceStruct
}

func (p *BalanceManager) Init(collection *MongoTrend.BalanceStruct) {
	p.balanceCollection = collection
}

func (p *BalanceManager) RecordBalance(balances ...MongoTrend.BalanceItemInfo) error {

	if p.balanceCollection == nil {
		return errors.New("Invalid mongo collection")
	}

	if balances == nil {
		return errors.New("Invalid parameters")
	}

	var balanceData MongoTrend.BalanceInfo
	for _, balance := range balances {
		balanceData.Item = append(balanceData.Item, balance)
	}

	if err := p.balanceCollection.Insert(balanceData); err != nil {
		return err
	}

	return nil
}

func (p *BalanceManager) SetBalanceStart(id string) error {

	if p.balanceCollection == nil {
		return errors.New("Invalid mongo collection")
	}

	return p.balanceCollection.Update(map[string]interface{}{
		"_id": bson.ObjectIdHex(id),
	}, map[string]interface{}{
		"start": true,
	})
}

func (p *BalanceManager) GetListFromLastStart() (error, []MongoTrend.BalanceInfo) {

	if p.balanceCollection == nil {
		return errors.New("Invalid mongo collection"), nil
	}

	err, balances := p.balanceCollection.FindAll(map[string]interface{}{
		"start": true,
	}, "-time")
	if err != nil {
		return err, nil
	} else if balances == nil || len(balances) == 0 {
		return errors.New("Not record is found"), nil
	}

	return p.balanceCollection.FindAll(map[string]interface{}{
		"time": bson.M{
			"$gte": balances[0].Time,
		},
	}, "time")
}

func (p *BalanceManager) GetDialyLast(date time.Time) (error, *MongoTrend.BalanceInfo) {

	if p.balanceCollection == nil {
		return errors.New("Invalid mongo collection"), nil
	}

	var result []MongoTrend.BalanceInfo
	var start, end time.Time
	var err error

	format := "2006-01-02"
	temp := date.Format(format)
	start, err = time.Parse(format, temp)
	if err != nil {
		return err, nil
	}

	end = start.AddDate(0, 0, 1).Add(-8 * time.Hour)
	start = start.Add(-8 * time.Hour)

	// log.Printf("Start:%v End:%v", start.Format(config.TimeFormat), end.Format(config.TimeFormat))

	err, result = p.balanceCollection.FindAll(map[string]interface{}{
		"time": bson.M{
			"$gte": start,
			"$lt":  end,
		},
	}, "-time")
	if err != nil {
		return err, nil
	}

	if result != nil && len(result) != 0 {
		// for _, data := range result {
		// 	log.Printf("Result:%v", data)
		// }
		return nil, &result[0]
	} else {
		return errors.New("No record found"), nil
	}

}
