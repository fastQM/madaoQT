package main

import (
	Exchange "madaoQT/exchange"
)

const FxcmToken = "549842745787ce52ee44e480fea506abdefb07e3"

var fxcm *Exchange.FXCM

func main() {
	fxcm = Exchange.GetFxcmInstance(Exchange.Config{
		Custom: map[string]interface{}{
			"token":   FxcmToken,
			"account": "96080958",
		},
		Proxy: "SOCKS5:127.0.0.1:1080",
	})
}

func GetKline(pair string, period int, limit int) []Exchange.KlineValue {
	if fxcm != nil {
		return fxcm.GetKline(pair, period, limit)
	} else {
		return nil
	}

}

//go build -buildmode=plugin -o eng/eng.so eng/greeter.go
