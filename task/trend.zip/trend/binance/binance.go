package main

import (
	"fmt"
	"log"
	"madaoQT/task/trend"
)

func main() {

	trendTask := new(trend.TrendTaskBinance)
	err := trendTask.Start("")
	if err != nil {
		log.Printf("Error:%v", err)
	}
	go func() {
		var cmd string
		for {
			fmt.Scanln(&cmd)

			switch cmd {
			case "c":
				trendTask.ForceClosePositions()
				cmd = ""
			}
		}
	}()
	select {}
}
